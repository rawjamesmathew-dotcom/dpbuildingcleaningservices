import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Star } from "lucide-react";
import SectionHeading from "@/components/site/SectionHeading";
import { SITE } from "@/lib/siteContent";

function Stars({ value = 5 }) {
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`Rated ${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((step) => (
        <Star
          key={step}
          aria-hidden="true"
          className={
            step <= Math.round(value)
              ? "h-3.5 w-3.5 fill-amber-400 text-amber-400"
              : "h-3.5 w-3.5 text-brand-line"
          }
        />
      ))}
    </span>
  );
}

function initialsOf(name = "") {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

export default function ReviewsSection({ reviews = [] }) {
  const list = reviews.filter((review) => review.text);
  const count = list.length;
  const average = count
    ? list.reduce((sum, review) => sum + (Number(review.rating) || 5), 0) / count
    : 0;

  return (
    <section className="relative overflow-hidden bg-white py-20 sm:py-28">
      <div className="shell">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="Reviews"
            title="Words from the buildings we look after."
            intro="Every review shown here was left by a real client and is published as it was given. We do not buy, edit or invent feedback."
          />
          <a
            href={SITE.mapUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex shrink-0 items-center gap-2 border-b border-brand-navy/20 pb-1.5 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue hover:text-brand-blue"
          >
            Find us on Google
            <ArrowUpRight
              className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
              aria-hidden="true"
            />
          </a>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-[300px_1fr]">
          <aside className="relative overflow-hidden rounded-[22px] bg-brand-navy p-7 text-white">
            <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-brand-blue/30 blur-3xl" />
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-brand-cyan">
              Overall rating
            </p>
            {count > 0 ? (
              <>
                <p className="mt-4 font-display text-[56px] font-extrabold leading-none tracking-[-0.04em]">
                  {average.toFixed(1)}
                </p>
                <div className="mt-4">
                  <Stars value={average} />
                </div>
                <p className="mt-3 text-[13px] text-white/60">
                  Based on {count} published review{count === 1 ? "" : "s"}
                </p>
              </>
            ) : (
              <>
                <p className="mt-4 font-display text-[30px] font-bold leading-tight">
                  Awaiting the first verified review
                </p>
                <div className="mt-4">
                  <Stars value={0} />
                </div>
              </>
            )}

            <Link
              to="/contact"
              className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:bg-brand-ice"
            >
              Send your feedback
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </aside>

          {count > 0 ? (
            <div className="grid gap-4 sm:grid-cols-2">
              {list.map((review) => (
                <article
                  key={review.id}
                  className="lift flex h-full flex-col rounded-[22px] border border-brand-line bg-white p-6"
                >
                  <div className="flex items-start gap-3">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-brand-ice font-display text-[14px] font-bold text-brand-blue">
                      {initialsOf(review.name)}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate font-display text-[14.5px] font-bold text-brand-navy">
                        {review.name}
                      </p>
                      {review.detail && (
                        <p className="truncate text-[12px] text-brand-slate">{review.detail}</p>
                      )}
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-3">
                    <Stars value={review.rating} />
                    {review.date && (
                      <span className="text-[11.5px] text-brand-slate/70">{review.date}</span>
                    )}
                  </div>
                  <p className="mt-3 flex-1 text-[14px] leading-[1.7] text-brand-slate">
                    “{review.text}”
                  </p>
                  <p className="mt-4 text-[11px] font-semibold uppercase tracking-[0.16em] text-brand-slate/60">
                    {review.source === "google"
                      ? "Google review"
                      : review.source === "email"
                        ? "By email"
                        : "Website"}
                  </p>
                </article>
              ))}
            </div>
          ) : (
            <div className="rounded-[22px] border border-dashed border-brand-line bg-brand-mist p-8 sm:p-10">
              <p className="font-display text-[19px] font-bold text-brand-navy">
                A review section you can trust.
              </p>
              <p className="mt-3 max-w-xl text-[14px] leading-[1.75] text-brand-slate">
                Nothing appears here until a genuine client review is published, because invented
                testimonials mislead the people reading them — and Google penalises them. Once a
                review is added by our team it shows in this layout, with its real star rating and
                the date it was given.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href={SITE.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-full bg-brand-navy px-5 py-3 text-[13.5px] font-semibold text-white transition-colors hover:bg-brand-blue"
                >
                  Review us on Google
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </a>
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 rounded-full border border-brand-line bg-white px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue"
                >
                  Request a quotation
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}