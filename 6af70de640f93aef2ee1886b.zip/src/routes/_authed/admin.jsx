import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { ShieldAlert } from "lucide-react";
import AdminShell from "@/components/admin/AdminShell";
import { Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/_authed/admin")({ component: AdminLayout });

function AdminLayout() {
  const user = Route.useRouteContext().user;
  const isAdmin = useMemo(() => user?.role === "admin", [user]);

  if (!isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-brand-navy px-5">
        <div className="w-full max-w-md rounded-3xl border border-white/15 bg-white/5 p-8 text-center backdrop-blur">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-white/10 text-brand-cyan">
            <ShieldAlert className="h-6 w-6" aria-hidden="true" />
          </span>
          <h1 className="display-md mt-6 text-white">Administrator access only</h1>
          <p className="mt-3 text-[14.5px] leading-relaxed text-white/60">
            This account is signed in but does not have permission to manage website content or
            submissions. Ask the site owner to grant administrator access.
          </p>
          <Link
            to="/"
            className="mt-7 inline-flex rounded-full bg-white px-6 py-3 text-[13.5px] font-semibold text-brand-navy"
          >
            Back to the website
          </Link>
        </div>
      </div>
    );
  }

  return (
    <AdminShell>
      <Outlet />
    </AdminShell>
  );
}