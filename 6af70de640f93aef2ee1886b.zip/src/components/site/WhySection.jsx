import { WHY_REASONS } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";
import SectionHeading from "@/components/site/SectionHeading";

export default function WhySection() {
  return (
    <section className="relative overflow-hidden bg-brand-navy py-20 sm:py-28">
      <div className="pointer-events-none absolute -right-32 top-10 h-[420px] w-[420px] rounded-full bg-brand-blue/20 blur-[130px]" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.16] [background-image:linear-gradient(rgba(255,255,255,0.28)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.28)_1px,transparent_1px)] [background-size:88px_88px]" />

      <div className="shell relative">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
          <SectionHeading
            eyebrow="Why work with us"
            tone="light"
            title="Standards you can hold us to."
            intro="No unverifiable claims — just the way we work, stated plainly so you know what to expect from the first message to the final check."
          />
          <p className="max-w-xs text-[13px] leading-relaxed text-white/45">
            Certification, insurance and team details will be published here once the company
            confirms the documentation.
          </p>
        </div>

        <div className="mt-14 grid gap-x-12 gap-y-0 border-t border-white/10 sm:grid-cols-2">
          {WHY_REASONS.map((reason, i) => (
            <Reveal key={reason.title} delay={(i % 2) * 0.06}>
              <div className="group flex gap-5 border-b border-white/10 py-7">
                <span className="mt-1 font-mono text-[11px] font-medium tracking-[0.1em] text-brand-cyan/70">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <h3 className="font-display text-[18px] font-semibold tracking-[-0.02em] text-white">
                    {reason.title}
                  </h3>
                  <p className="mt-2.5 max-w-md text-[14.5px] leading-relaxed text-white/60">
                    {reason.body}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}