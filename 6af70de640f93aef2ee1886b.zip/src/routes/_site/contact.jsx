import { createFileRoute } from "@tanstack/react-router";
import { Mail, MessageSquare, Clock, MapPin, Phone } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import ContactForm from "@/components/forms/ContactForm";
import LocationMap from "@/components/site/LocationMap";
import { SITE } from "@/lib/siteContent";
import { getPublicSettings } from "@/lib/content-fns";

export const Route = createFileRoute("/_site/contact")({
  component: ContactPage,
  loader: () => getPublicSettings(),
  head: () => ({
    meta: [
      { title: "Contact Us | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "Contact Deshani Prasang Building Services by email or through the website form to discuss cleaning, building services and repair requirements.",
      },
      { property: "og:title", content: "Contact Deshani Prasang Building Services" },
      { property: "og:description", content: "Email our team or send a message through the site." },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
});

function ContactPage() {
  const settings = Route.useLoaderData();

  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title="Talk to the team directly."
        intro="Email is the fastest way to reach us. For a quotation, the quote request form collects the details we need to review a property properly."
      />

      <section className="bg-brand-mist py-14 sm:py-20">
        <div className="shell grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-brand-line bg-white p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-ice text-brand-blue">
                  <Mail className="h-5 w-5" aria-hidden="true" />
                </span>
                <h2 className="font-display text-[16px] font-bold text-brand-navy">Email</h2>
              </div>
              <ul className="mt-4 space-y-3">
                <li>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-brand-slate">
                    General &amp; quotations
                  </p>
                  <a
                    href={`mailto:${settings.primary_email}`}
                    className="mt-1 block break-all text-[14px] font-medium text-brand-navy hover:text-brand-blue"
                  >
                    {settings.primary_email}
                  </a>
                </li>
                <li>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-brand-slate">
                    HR &amp; careers
                  </p>
                  <a
                    href={`mailto:${settings.hr_email}`}
                    className="mt-1 block break-all text-[14px] font-medium text-brand-navy hover:text-brand-blue"
                  >
                    {settings.hr_email}
                  </a>
                  <p className="mt-1 text-[11.5px] text-brand-slate/70">
                    Address shown exactly as supplied by the company.
                  </p>
                </li>
              </ul>
            </div>

            <div className="rounded-[22px] border border-brand-line bg-white p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-ice text-brand-blue">
                  <MessageSquare className="h-5 w-5" aria-hidden="true" />
                </span>
                <h2 className="font-display text-[16px] font-bold text-brand-navy">
                  Phone &amp; WhatsApp
                </h2>
              </div>
              {settings.phone || settings.whatsapp ? (
                <div className="mt-4 space-y-3">
                  {settings.phone && (
                    <a
                      href={`tel:${settings.phone.replace(/\s+/g, "")}`}
                      className="flex items-center gap-2 text-[14px] font-medium text-brand-navy hover:text-brand-blue"
                    >
                      <Phone className="h-4 w-4 text-brand-blue" aria-hidden="true" />
                      {settings.phone}
                    </a>
                  )}
                  {settings.whatsapp && (
                    <a
                      href={`https://wa.me/${settings.whatsapp.replace(/[^\d]/g, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-[14px] font-medium text-brand-navy hover:text-brand-blue"
                    >
                      <MessageSquare className="h-4 w-4 text-brand-blue" aria-hidden="true" />
                      WhatsApp {settings.whatsapp}
                    </a>
                  )}
                </div>
              ) : (
                <p className="mt-3 text-[13px] leading-relaxed text-brand-slate">
                  Not published yet. We will not display a phone number or WhatsApp link until the
                  company confirms a verified number — a wrong number is worse than none. Email works
                  in the meantime.
                </p>
              )}
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
              <div className="rounded-[22px] border border-brand-line bg-white p-6">
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-brand-blue" aria-hidden="true" />
                  <h2 className="font-display text-[14.5px] font-bold text-brand-navy">
                    Working hours
                  </h2>
                </div>
                <p className="mt-2 text-[13px] leading-relaxed text-brand-slate">
                  {settings.working_hours ||
                    "Hours are confirmed with the company before publication. Requests submitted at any time are logged and reviewed by our team."}
                </p>
              </div>
              <div className="rounded-[22px] border border-brand-line bg-white p-6">
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-brand-blue" aria-hidden="true" />
                  <h2 className="font-display text-[14.5px] font-bold text-brand-navy">
                    Address &amp; service area
                  </h2>
                </div>
                <p className="mt-2 text-[13px] leading-relaxed text-brand-slate">
                  {settings.address ||
                    "A public address and service coverage will be listed once confirmed. Tell us the location in your request and we will confirm availability."}
                </p>
                <a
                  href={SITE.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-brand-blue hover:text-brand-navy"
                >
                  <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                  Open in Google Maps
                </a>
              </div>
            </div>
          </div>

          <div>
            <ContactForm />
            <p className="mt-4 px-1 text-[12px] leading-relaxed text-brand-slate">
              {SITE.responseNote} We do not promise a fixed response time; every message is answered
              in turn by our team.
            </p>
          </div>
        </div>
      </section>

      <LocationMap />
    </>
  );
}