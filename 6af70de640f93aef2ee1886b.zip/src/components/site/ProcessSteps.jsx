import { PROCESS_STEPS } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";
import SectionHeading from "@/components/site/SectionHeading";

export default function ProcessSteps() {
  return (
    <section className="bg-brand-mist py-20 sm:py-28">
      <div className="shell">
        <SectionHeading
          eyebrow="How it works"
          title="From first message to finished work."
          intro="A quotation is a proposal, not a confirmed booking. Work is only scheduled once the scope, timing and price are accepted by both sides."
        />

        <ol className="mt-14 grid gap-px overflow-hidden rounded-3xl border border-brand-line bg-brand-line md:grid-cols-5">
          {PROCESS_STEPS.map((step, i) => (
            <li key={step.step} className="relative bg-white">
              <Reveal delay={i * 0.06} className="h-full">
                <div className="group flex h-full flex-col p-6 transition-colors duration-500 hover:bg-brand-ice/60">
                  <span className="font-mono text-[11px] font-medium tracking-[0.14em] text-brand-blue">
                    {step.step}
                  </span>
                  <h3 className="mt-4 font-display text-[16.5px] font-bold leading-snug tracking-[-0.02em] text-brand-navy">
                    {step.title}
                  </h3>
                  <p className="mt-2.5 text-[13.5px] leading-relaxed text-brand-slate">{step.body}</p>
                  <span className="mt-auto pt-6">
                    <span className="block h-px w-full bg-brand-line">
                      <span className="block h-px w-0 bg-brand-blue transition-all duration-700 group-hover:w-full" />
                    </span>
                  </span>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}