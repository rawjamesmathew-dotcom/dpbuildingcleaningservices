import { Link } from "@tanstack/react-router";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FAQS } from "@/lib/siteContent";

export default function FaqAccordion({ faqs = FAQS }) {
  return (
    <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
      <div>
        <p className="eyebrow flex items-center gap-3">
          <span className="h-px w-8 bg-brand-blue/60" />
          Questions
        </p>
        <h2 className="display-lg mt-4 text-brand-navy">Answers before you ask.</h2>
        <p className="mt-5 text-[16px] leading-relaxed text-brand-slate">
          Anything not covered here can be sent straight to our team.
        </p>
        <Link
          to="/contact"
          className="mt-7 inline-flex items-center gap-2 rounded-full border border-brand-line px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue hover:bg-brand-ice"
        >
          Ask us a question
        </Link>
      </div>

      <Accordion type="single" collapsible className="w-full">
        {faqs.map((item, i) => (
          <AccordionItem
            key={item.q}
            value={`faq-${i}`}
            className="border-b border-brand-line last:border-b-0"
          >
            <AccordionTrigger className="py-5 text-left font-display text-[16px] font-semibold tracking-[-0.015em] text-brand-navy hover:text-brand-blue hover:no-underline">
              {item.q}
            </AccordionTrigger>
            <AccordionContent className="pb-6 pr-6 text-[14.5px] leading-relaxed text-brand-slate">
              {item.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}