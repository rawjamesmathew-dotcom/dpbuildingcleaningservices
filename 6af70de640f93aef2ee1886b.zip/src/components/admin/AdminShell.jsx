import { Link, Outlet } from "@tanstack/react-router";
import { useLocation } from "@tanstack/react-router";
import { useAuth } from "@/lib/AuthContext";
import BrandMark from "@/components/site/BrandMark";
import { cn } from "@/lib/utils";
import {
  ArrowUpRight,
  Briefcase,
  FolderOpen,
  Inbox,
  LayoutDashboard,
  LogOut,
  MessageSquareQuote,
  Settings,
  Star,
  Wrench,
} from "lucide-react";

const LINKS = [
  { to: "/admin", label: "Overview", icon: LayoutDashboard, exact: true },
  { to: "/admin/inquiries", label: "Enquiries", icon: Inbox },
  { to: "/admin/quotes", label: "Quote requests", icon: MessageSquareQuote },
  { to: "/admin/applications", label: "Applications", icon: Briefcase },
  { to: "/admin/services", label: "Services", icon: Wrench },
  { to: "/admin/projects", label: "Gallery", icon: FolderOpen },
  { to: "/admin/reviews", label: "Reviews", icon: Star },
  { to: "/admin/settings", label: "Site settings", icon: Settings },
];

export default function AdminShell({ children }) {
  const { pathname } = useLocation();
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-brand-mist">
      <div className="mx-auto flex w-full max-w-[1440px] flex-col lg:flex-row">
        <aside className="border-b border-brand-line bg-white lg:min-h-screen lg:w-64 lg:border-b-0 lg:border-r">
          <div className="flex items-center justify-between gap-3 px-5 py-5">
            <BrandMark />
          </div>
          <div className="px-5 pb-4">
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-brand-slate">
              Admin area
            </p>
          </div>
          <nav aria-label="Admin" className="flex gap-1 overflow-x-auto px-3 pb-4 lg:flex-col lg:overflow-visible">
            {LINKS.map((link) => {
              const Icon = link.icon;
              const active = link.exact ? pathname === link.to : pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={cn(
                    "flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-[13.5px] font-medium transition-colors",
                    active
                      ? "bg-brand-navy text-white"
                      : "text-brand-slate hover:bg-brand-ice hover:text-brand-navy"
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                  {link.label}
                </Link>
              );
            })}
          </nav>
          <div className="hidden border-t border-brand-line px-5 py-5 lg:block">
            <p className="text-[12px] text-brand-slate">Signed in as</p>
            <p className="mt-1 truncate text-[13px] font-semibold text-brand-navy">{user?.email}</p>
            <div className="mt-4 flex flex-col gap-2">
              <a
                href="/"
                className="inline-flex items-center gap-1.5 text-[12.5px] font-medium text-brand-blue hover:underline"
              >
                View website
                <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
              <button
                type="button"
                onClick={() => logout()}
                className="inline-flex items-center gap-1.5 text-left text-[12.5px] font-medium text-brand-slate hover:text-brand-navy"
              >
                <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
                Sign out
              </button>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 px-5 py-8 sm:px-8 lg:py-10">{children ?? <Outlet />}</main>
      </div>
    </div>
  );
}