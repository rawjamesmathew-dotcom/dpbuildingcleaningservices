import { createFileRoute } from "@tanstack/react-router";
import PageHeader from "@/components/site/PageHeader";
import QuoteForm from "@/components/forms/QuoteForm";
import { SITE, SERVICES } from "@/lib/siteContent";

export const Route = createFileRoute("/_site/quote")({
  component: QuotePage,
  head: () => ({
    meta: [
      { title: "Get a Free Quote | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "Request a quotation for building cleaning, office cleaning, facade, floor care, deep cleaning or home repairs. Every request is reviewed by our team.",
      },
      { property: "og:title", content: "Get a Free Quote" },
      { property: "og:description", content: "Tell us about the property and request a quotation." },
    ],
    links: [{ rel: "canonical", href: "/quote" }],
  }),
});

function QuotePage() {
  return (
    <>
      <PageHeader
        eyebrow="Get a quote"
        title="Tell us about the property."
        intro="The more detail you give, the more accurate the quotation. Nothing is booked by submitting this form — our team reviews every request first."
      />

      <section className="bg-brand-mist py-14 sm:py-20">
        <div className="shell grid gap-10 lg:grid-cols-[1.35fr_0.65fr] lg:gap-14">
          <QuoteForm />

          <aside className="space-y-4">
            <div className="rounded-[22px] border border-brand-line bg-white p-6">
              <h2 className="font-display text-[16px] font-bold text-brand-navy">
                What happens next
              </h2>
              <ol className="mt-4 space-y-3">
                {[
                  "We read your request and check the scope.",
                  "We contact you if anything needs clarifying.",
                  "You receive a quotation for the agreed scope.",
                  "Work is scheduled only once both sides accept.",
                ].map((item, i) => (
                  <li key={item} className="flex gap-3 text-[13.5px] leading-relaxed text-brand-slate">
                    <span className="mt-0.5 font-mono text-[11px] text-brand-blue">0{i + 1}</span>
                    {item}
                  </li>
                ))}
              </ol>
            </div>

            <div className="rounded-[22px] border border-brand-line bg-white p-6">
              <h2 className="font-display text-[16px] font-bold text-brand-navy">
                Prefer to email?
              </h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-brand-slate">
                Send your requirement directly to our team and we will reply by email.
              </p>
              <a
                href={`mailto:${SITE.emails.primary}?subject=Quotation%20request`}
                className="mt-4 inline-flex break-all text-[13.5px] font-semibold text-brand-blue hover:underline"
              >
                {SITE.emails.primary}
              </a>
            </div>

            <div className="rounded-[22px] border border-brand-line bg-brand-navy p-6 text-white">
              <h2 className="font-display text-[16px] font-bold">Services you can request</h2>
              <ul className="mt-4 space-y-2 text-[13px] text-white/65">
                {SERVICES.map((service) => (
                  <li key={service.slug}>— {service.name}</li>
                ))}
              </ul>
            </div>

            <p className="px-2 text-[12px] leading-relaxed text-brand-slate">{SITE.responseNote}</p>
          </aside>
        </div>
      </section>
    </>
  );
}