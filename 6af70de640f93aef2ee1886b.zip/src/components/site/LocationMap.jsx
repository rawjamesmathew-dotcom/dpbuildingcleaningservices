import { ArrowUpRight, MapPin, Navigation } from "lucide-react";
import { SITE } from "@/lib/siteContent";

const embedSrc = `https://maps.google.com/maps?q=${encodeURIComponent(
  SITE.address.full
)}&z=16&output=embed`;

export default function LocationMap() {
  return (
    <section className="bg-brand-navy py-16 sm:py-20" aria-label="Our location">
      <div className="shell grid items-center gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-12">
        <div className="text-white">
          <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-brand-cyan">
            <span className="h-px w-10 bg-brand-cyan/70" />
            Our location
          </p>
          <h2 className="display-lg mt-5 max-w-md text-white">Based in Al Nahda, Dubai.</h2>
          <p className="mt-5 max-w-md text-[15.5px] leading-[1.75] text-white/65">
            Visits are arranged across Dubai and the surrounding areas. Share the property location
            in your request and we will confirm coverage before quoting.
          </p>

          <div className="mt-7 flex items-start gap-3 rounded-2xl border border-white/15 bg-white/5 p-4">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan" aria-hidden="true" />
            <p className="text-[14px] leading-relaxed text-white/80">
              {SITE.address.line1}
              <br />
              {SITE.address.line2}
              <br />
              {SITE.address.city}
            </p>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href={SITE.mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:bg-brand-cyan"
            >
              <Navigation className="h-4 w-4" aria-hidden="true" />
              Get directions
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(SITE.address.full)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-white/25 px-5 py-3 text-[13.5px] font-semibold text-white transition-colors hover:border-white/60 hover:bg-white/10"
            >
              Open in Google Maps
              <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </div>
        </div>

        <div className="overflow-hidden rounded-[22px] border border-white/15 shadow-[0_40px_90px_-50px_rgba(0,0,0,0.8)]">
          <iframe
            title="Deshani Prasang Building Services location on Google Maps"
            src={embedSrc}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
            className="h-[320px] w-full border-0 sm:h-[400px]"
          />
        </div>
      </div>
    </section>
  );
}