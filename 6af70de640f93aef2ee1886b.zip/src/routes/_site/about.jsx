import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import PageHeader from "@/components/site/PageHeader";
import SectionHeading from "@/components/site/SectionHeading";
import Reveal from "@/components/site/Reveal";
import ProcessSteps from "@/components/site/ProcessSteps";
import { ABOUT_VALUES, IMAGES, SITE, STANDARDS } from "@/lib/siteContent";

export const Route = createFileRoute("/_site/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About Us | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "How Deshani Prasang Building Services works: scope agreed in advance, defined service standards and a direct point of contact for every request.",
      },
      { property: "og:title", content: "About Deshani Prasang Building Services" },
      {
        property: "og:description",
        content: "Our approach, values and the service standard we work to.",
      },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
});

function AboutPage() {
  return (
    <>
      <PageHeader
        eyebrow="About us"
        title="A cleaning partner, not just a visit."
        intro="We work with businesses, property managers and homeowners who want a defined service rather than an open-ended promise. Here is how we think about the work."
      />

      <section className="bg-white py-20 sm:py-28">
        <div className="shell grid gap-12 lg:grid-cols-[1fr_1.05fr] lg:items-center lg:gap-16">
          <Reveal>
            <div className="relative overflow-hidden rounded-[26px] border border-brand-line">
              <Image
                src={IMAGES.about}
                alt="Close-up of a gloved hand cleaning a chrome handrail in a glass atrium"
                className="h-[360px] w-full object-cover sm:h-[460px]"
                fittingType="fill"
              />
            </div>
          </Reveal>
          <div>
            <SectionHeading eyebrow="The company" title="What we do, stated plainly." />
            <div className="mt-6 space-y-4 text-[16.5px] leading-[1.75] text-brand-slate">
              <p>
                {SITE.intro} Our work covers offices, commercial buildings, residential buildings
                and shared spaces, with a quotation prepared for each property rather than a fixed
                package.
              </p>
              <p>
                Alongside cleaning, we take on home works and repair jobs, so a single team can
                handle the cleaning programme and the maintenance a property needs. Both are scoped
                the same way: understand the requirement first, then confirm what the work includes.
              </p>
              <p className="rounded-2xl border border-brand-line bg-brand-mist p-5 text-[14.5px]">
                <span className="font-semibold text-brand-navy">Registered name:</span>{" "}
                {SITE.legalName}. Company history, certifications and team details will be published
                once the company provides the supporting documentation.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-brand-mist py-20 sm:py-28">
        <div className="shell grid gap-10 lg:grid-cols-2 lg:gap-16">
          <Reveal>
            <div className="h-full rounded-[24px] border border-brand-line bg-white p-8">
              <p className="eyebrow">Mission</p>
              <h2 className="display-md mt-4 text-brand-navy">
                Make a defined standard of cleanliness the normal expectation.
              </h2>
              <p className="mt-4 text-[15.5px] leading-relaxed text-brand-slate">
                Our mission is to give every client a clear picture of what is being delivered, how
                often, and to what standard — so quality is something you can verify rather than
                hope for.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <div className="h-full rounded-[24px] border border-brand-line bg-brand-navy p-8 text-white">
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-brand-cyan">
                Vision
              </p>
              <h2 className="display-md mt-4">
                The building services partner properties keep.
              </h2>
              <p className="mt-4 text-[15.5px] leading-relaxed text-white/65">
                We want to be the team a property manager calls first — for routine cleaning, for the
                difficult deep clean, and for the repair that needs doing properly.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-white py-20 sm:py-28">
        <div className="shell">
          <SectionHeading
            eyebrow="Values"
            title="Four things we won't trade away."
            intro="Values only matter if they change how the work is done. These are the ones that shape ours."
          />
          <div className="mt-12 grid gap-px overflow-hidden rounded-3xl border border-brand-line bg-brand-line sm:grid-cols-2 lg:grid-cols-4">
            {ABOUT_VALUES.map((value, i) => (
              <Reveal key={value.title} delay={i * 0.06} className="h-full">
                <div className="h-full bg-white p-7">
                  <span className="font-mono text-[11px] tracking-[0.14em] text-brand-blue">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className="mt-4 font-display text-[17px] font-bold text-brand-navy">
                    {value.title}
                  </h3>
                  <p className="mt-2.5 text-[14px] leading-relaxed text-brand-slate">{value.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-brand-mist py-20 sm:py-28">
        <div className="shell">
          <SectionHeading
            eyebrow="Quality process"
            title="How quality is held, visit after visit."
          />
          <div className="mt-10 grid gap-6 sm:grid-cols-2">
            {STANDARDS.map((item) => (
              <div
                key={item.label}
                className="flex gap-4 rounded-2xl border border-brand-line bg-white p-6"
              >
                <span className="font-mono text-[11px] tracking-[0.14em] text-brand-blue">
                  {item.label}
                </span>
                <div>
                  <h3 className="font-display text-[16px] font-bold text-brand-navy">{item.title}</h3>
                  <p className="mt-2 text-[14px] leading-relaxed text-brand-slate">{item.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ProcessSteps />

      <section className="bg-white py-16">
        <div className="shell flex flex-col items-start justify-between gap-6 rounded-[26px] border border-brand-line bg-brand-mist p-8 sm:flex-row sm:items-center sm:p-10">
          <div>
            <h2 className="display-md text-brand-navy">Want to discuss a property?</h2>
            <p className="mt-2 max-w-xl text-[15px] text-brand-slate">
              Send the details and our team will review them before any commitment is made.
            </p>
          </div>
          <Link
            to="/quote"
            className="group inline-flex shrink-0 items-center gap-2 rounded-full bg-brand-navy px-6 py-3.5 text-[14px] font-semibold text-white transition-colors hover:bg-brand-blue"
          >
            Get a free quote
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
          </Link>
        </div>
      </section>
    </>
  );
}