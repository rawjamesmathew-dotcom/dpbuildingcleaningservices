import { Building2, Layers, ClipboardCheck } from "lucide-react";
import { HIGHLIGHTS } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";

const ICONS = [Building2, Layers, ClipboardCheck];

export default function Highlights() {
  return (
    <section aria-label="Service highlights" className="relative z-10 bg-white">
      <div className="shell -mt-px">
        <div className="grid gap-px overflow-hidden rounded-3xl border border-brand-line bg-brand-line sm:grid-cols-3">
          {HIGHLIGHTS.map((item, i) => {
            const Icon = ICONS[i] ?? Building2;
            return (
              <Reveal key={item.title} delay={i * 0.08} className="h-full">
                <div className="group h-full bg-white p-7 transition-colors duration-500 hover:bg-brand-mist sm:p-8">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-ice text-brand-blue transition-colors duration-500 group-hover:bg-brand-blue group-hover:text-white">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h2 className="mt-6 font-display text-[19px] font-bold tracking-[-0.02em] text-brand-navy">
                    {item.title}
                  </h2>
                  <p className="mt-3 text-[15px] leading-relaxed text-brand-slate">{item.body}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}