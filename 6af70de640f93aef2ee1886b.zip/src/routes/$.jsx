import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Home, Mail } from "lucide-react";
import Navbar from "@/components/site/Navbar";
import Footer from "@/components/site/Footer";
import { SITE } from "@/lib/siteContent";

export const Route = createFileRoute("/$")({
  component: NotFoundPage,
  head: () => ({
    meta: [
      { title: "Page not found | Deshani Prasang Building Services" },
      { name: "robots", content: "noindex" },
    ],
  }),
});

function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col bg-brand-navy">
      <Navbar />
      <main className="flex flex-1 items-center justify-center px-5 py-32">
        <div className="w-full max-w-xl text-center">
          <p className="font-mono text-[12px] font-medium uppercase tracking-[0.3em] text-brand-cyan">
            404
          </p>
          <h1 className="display-lg mt-5 text-white">This page isn&rsquo;t part of the building.</h1>
          <p className="mt-5 text-[16px] leading-relaxed text-white/60">
            The link may be out of date, or the page may have moved. Everything on the site is
            reachable from the pages below.
          </p>
          <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
            <Link
              to="/"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-6 py-3.5 text-[14px] font-semibold text-brand-navy transition-colors hover:bg-brand-cyan"
            >
              <Home className="h-4 w-4" aria-hidden="true" />
              Back to home
            </Link>
            <Link
              to="/services"
              className="group inline-flex items-center justify-center gap-2 rounded-full border border-white/25 px-6 py-3.5 text-[14px] font-semibold text-white transition-colors hover:border-white/60 hover:bg-white/10"
            >
              Browse services
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </div>
          <a
            href={`mailto:${SITE.emails.primary}`}
            className="mt-8 inline-flex items-center gap-2 text-[13.5px] text-white/50 transition-colors hover:text-white"
          >
            <Mail className="h-4 w-4" aria-hidden="true" />
            {SITE.emails.primary}
          </a>
        </div>
      </main>
      <Footer />
    </div>
  );
}