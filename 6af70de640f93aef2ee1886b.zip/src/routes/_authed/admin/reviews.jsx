const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { Plus, Star, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_authed/admin/reviews")({ component: ReviewsAdmin });

const EMPTY = {
  reviewer_name: "",
  reviewer_detail: "",
  rating: 5,
  text: "",
  source: "google",
  review_date: "",
  published: true,
  display_order: 0,
};

const inputClass =
  "w-full rounded-xl border border-brand-line bg-white px-3.5 py-2.5 text-[13.5px] text-brand-navy focus:border-brand-blue focus:outline-none";

function ReviewsAdmin() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");

  const load = async () => {
    setLoading(true);
    const page = await db.entities.Review.list("-created_date", 100);
    const list = (Array.isArray(page) ? page : page?.items ?? []).sort(
      (a, b) => (a.display_order ?? 0) - (b.display_order ?? 0)
    );
    setItems(list);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const startEdit = (item) => {
    setEditingId(item.id);
    setForm({
      reviewer_name: item.reviewer_name ?? "",
      reviewer_detail: item.reviewer_detail ?? "",
      rating: item.rating ?? 5,
      text: item.text ?? "",
      source: item.source ?? "google",
      review_date: item.review_date ?? "",
      published: item.published !== false,
      display_order: item.display_order ?? 0,
    });
    setNotice("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const reset = () => {
    setEditingId(null);
    setForm(EMPTY);
  };

  const save = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.reviewer_name.trim() || !form.text.trim()) {
      setNotice("A reviewer name and the review text are required.");
      return;
    }
    setSaving(true);
    const payload = {
      ...form,
      rating: Number(form.rating) || 5,
      display_order: Number(form.display_order) || 0,
    };
    try {
      if (editingId) {
        await db.entities.Review.update(editingId, payload);
        setNotice("Review updated — the website now shows these changes.");
      } else {
        await db.entities.Review.create(payload);
        setNotice("Review added — it is now live on the website.");
      }
      reset();
      await load();
    } catch (error) {
      setNotice("Could not save. Check the details and try again.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this review? It will disappear from the website.")) return;
    await db.entities.Review.delete(id);
    if (editingId === id) reset();
    await load();
  };

  return (
    <div>
      <header className="mb-6">
        <h1 className="display-md text-brand-navy">Reviews</h1>
        <p className="mt-2 max-w-2xl text-[14px] text-brand-slate">
          Only real reviews belong here. Add what a client actually wrote and it appears on the home
          page in a Google-style card with its star rating. The average rating is calculated from
          these entries, so nothing is invented.
        </p>
      </header>

      <form onSubmit={save} className="rounded-2xl border border-brand-line bg-white p-5 sm:p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-[15px] font-bold text-brand-navy">
            {editingId ? "Edit review" : "Add a review"}
          </h2>
          {editingId && (
            <button
              type="button"
              onClick={reset}
              className="text-[12.5px] font-medium text-brand-slate hover:text-brand-navy"
            >
              Cancel edit
            </button>
          )}
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Reviewer name
            <input
              className={`${inputClass} mt-1.5`}
              value={form.reviewer_name}
              onChange={(event) => setForm({ ...form, reviewer_name: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Role or building
            <input
              className={`${inputClass} mt-1.5`}
              value={form.reviewer_detail}
              onChange={(event) => setForm({ ...form, reviewer_detail: event.target.value })}
              placeholder="Facilities manager, Al Nahda"
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Rating
            <select
              className={`${inputClass} mt-1.5`}
              value={form.rating}
              onChange={(event) => setForm({ ...form, rating: Number(event.target.value) })}
            >
              {[5, 4, 3, 2, 1].map((value) => (
                <option key={value} value={value}>
                  {value} star{value === 1 ? "" : "s"}
                </option>
              ))}
            </select>
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Where it was left
            <select
              className={`${inputClass} mt-1.5`}
              value={form.source}
              onChange={(event) => setForm({ ...form, source: event.target.value })}
            >
              <option value="google">Google</option>
              <option value="website">Website</option>
              <option value="email">Email</option>
            </select>
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Date shown
            <input
              className={`${inputClass} mt-1.5`}
              value={form.review_date}
              onChange={(event) => setForm({ ...form, review_date: event.target.value })}
              placeholder="November 2026"
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Display order
            <input
              type="number"
              className={`${inputClass} mt-1.5`}
              value={form.display_order}
              onChange={(event) => setForm({ ...form, display_order: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Review text (exactly as written)
            <textarea
              className={`${inputClass} mt-1.5 min-h-[110px]`}
              value={form.text}
              onChange={(event) => setForm({ ...form, text: event.target.value })}
            />
          </label>
          <label className="flex items-center gap-2 text-[13px] text-brand-navy sm:col-span-2">
            <input
              type="checkbox"
              checked={form.published}
              onChange={(event) => setForm({ ...form, published: event.target.checked })}
              className="h-4 w-4 rounded border-brand-line text-brand-blue"
            />
            Published on the website
          </label>
        </div>

        {notice && (
          <p className="mt-4 rounded-xl bg-brand-ice p-3 text-[12.5px] text-brand-navy">{notice}</p>
        )}

        <button
          type="submit"
          disabled={saving}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand-navy px-5 py-2.5 text-[13px] font-semibold text-white disabled:opacity-60"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          {saving ? "Saving" : editingId ? "Save changes" : "Add review"}
        </button>
      </form>

      <div className="mt-8 space-y-2">
        {loading ? (
          <p className="text-[13px] text-brand-slate">Loading reviews…</p>
        ) : items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-brand-line bg-white p-6 text-[13px] text-brand-slate">
            No reviews yet. The website shows an honest empty state until the first real review is
            added here.
          </p>
        ) : (
          items.map((item) => (
            <div
              key={item.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand-line bg-white px-4 py-3"
            >
              <div className="min-w-0">
                <p className="flex items-center gap-2 truncate text-[13.5px] font-semibold text-brand-navy">
                  {item.reviewer_name}
                  <span className="inline-flex items-center gap-0.5 text-[11.5px] font-medium text-brand-slate">
                    <Star className="h-3 w-3 fill-amber-400 text-amber-400" aria-hidden="true" />
                    {item.rating ?? 5}
                  </span>
                  {item.published === false && (
                    <span className="rounded-full bg-brand-mist px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.1em] text-brand-slate">
                      hidden
                    </span>
                  )}
                </p>
                <p className="truncate text-[12px] text-brand-slate">{item.text}</p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => startEdit(item)}
                  className="rounded-lg border border-brand-line px-3 py-1.5 text-[12.5px] font-medium text-brand-navy hover:border-brand-blue"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => remove(item.id)}
                  aria-label={`Delete review by ${item.reviewer_name}`}
                  className="rounded-lg border border-red-200 px-2.5 py-1.5 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}