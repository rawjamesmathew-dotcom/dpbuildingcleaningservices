import { createFileRoute, Link } from "@tanstack/react-router";
import PageHeader from "@/components/site/PageHeader";
import { SITE } from "@/lib/siteContent";

export const Route = createFileRoute("/_site/terms")({
  component: TermsPage,
  head: () => ({
    meta: [
      { title: "Terms & Conditions | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "The basis on which quotations, scheduling and services are provided through the Deshani Prasang Building Services website.",
      },
      { property: "og:title", content: "Terms & Conditions" },
      { property: "og:description", content: "How quotations and services are agreed." },
    ],
    links: [{ rel: "canonical", href: "/terms" }],
  }),
});

const SECTIONS = [
  {
    title: "1. Website content",
    body: "This website describes the services the company provides and how to request them. Descriptions are indicative; the scope that applies to your property is the scope stated in your quotation.",
  },
  {
    title: "2. Requests and quotations",
    body: "Submitting a form is a request for information, not a booking. A quotation is prepared after the requirement is reviewed and is valid for the period stated on it. Work is confirmed only once both sides accept the scope, schedule and price.",
  },
  {
    title: "3. Images and illustrations",
    body: "Images on this website that are marked illustrative show the types of environments the services are designed for. They are not photographs of completed company projects.",
  },
  {
    title: "4. Scheduling and access",
    body: "Dates and times are agreed in advance. Where a visit depends on access, keys or authorisations, those arrangements are confirmed before the service is delivered.",
  },
  {
    title: "5. Changes to scope",
    body: "If your requirement changes after a quotation is issued, we will review it and confirm whether the price or schedule is affected before any additional work proceeds.",
  },
  {
    title: "6. Careers applications",
    body: "Applications submitted through this website are reviewed by the company. Submitting an application does not create an employment relationship or guarantee an interview.",
  },
  {
    title: "7. Liability",
    body: "Nothing on this website excludes liability that cannot be excluded by law. Specific service terms are agreed with each client as part of the quotation process.",
  },
  {
    title: "8. Contact",
    body: `Questions about these terms can be sent to ${SITE.emails.primary}.`,
  },
];

function TermsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Terms"
        title="Terms & Conditions"
        intro="The basis on which quotations, scheduling and services are provided."
      />

      <section className="bg-white py-16 sm:py-24">
        <div className="shell max-w-3xl">
          <p className="rounded-2xl border border-brand-line bg-brand-mist p-5 text-[13px] leading-relaxed text-brand-slate">
            <span className="font-semibold text-brand-navy">Review note:</span> these terms are a
            working template for the website. They must be reviewed against the company&rsquo;s
            registered jurisdiction, contracting practice and insurance arrangements before
            publication.
          </p>

          <div className="mt-10 space-y-8">
            {SECTIONS.map((section) => (
              <div key={section.title}>
                <h2 className="font-display text-[19px] font-bold tracking-[-0.02em] text-brand-navy">
                  {section.title}
                </h2>
                <p className="mt-2.5 text-[15.5px] leading-[1.75] text-brand-slate">{section.body}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-wrap gap-4 border-t border-brand-line pt-8">
            <Link to="/privacy" className="text-[14px] font-semibold text-brand-blue hover:underline">
              Privacy Policy
            </Link>
            <Link to="/contact" className="text-[14px] font-semibold text-brand-blue hover:underline">
              Contact the team
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}