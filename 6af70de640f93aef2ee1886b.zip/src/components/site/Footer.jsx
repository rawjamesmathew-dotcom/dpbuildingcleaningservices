import { Link } from "@tanstack/react-router";
import { ArrowUp, Mail, MapPin } from "lucide-react";
import { NAV_LINKS, SERVICES, SITE } from "@/lib/siteContent";
import BrandMark from "@/components/site/BrandMark";

const year = new Date().getFullYear();

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-brand-navy text-white/70">
      <div className="pointer-events-none absolute -left-40 top-0 h-[420px] w-[420px] rounded-full bg-brand-blue/20 blur-[120px]" />
      <div className="shell relative py-16 sm:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <BrandMark tone="light" />
            <p className="mt-6 max-w-sm text-[15px] leading-relaxed text-white/60">
              {SITE.description}
            </p>
            <p className="mt-5 text-[11px] font-semibold uppercase tracking-[0.22em] text-white/35">
              {SITE.legalName}
            </p>
          </div>

          <nav aria-label="Footer navigation">
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.24em] text-white/40">
              Explore
            </h2>
            <ul className="mt-5 space-y-3">
              {[...NAV_LINKS, { label: "Get a Quote", to: "/quote" }, { label: "FAQ", to: "/faq" }].map(
                (link) => (
                  <li key={link.to}>
                    <Link
                      to={link.to}
                      className="text-[15px] text-white/70 transition-colors hover:text-white"
                    >
                      {link.label}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </nav>

          <nav aria-label="Footer services">
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.24em] text-white/40">
              Services
            </h2>
            <ul className="mt-5 space-y-3">
              {SERVICES.map((service) => (
                <li key={service.slug}>
                  <Link
                    to="/services/$slug"
                    params={{ slug: service.slug }}
                    className="text-[15px] text-white/70 transition-colors hover:text-white"
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.24em] text-white/40">
              Contact
            </h2>
            <ul className="mt-5 space-y-4">
              <li>
                <a
                  href={`mailto:${SITE.emails.primary}`}
                  className="group inline-flex items-start gap-2.5 text-[15px] text-white/80 transition-colors hover:text-white"
                >
                  <Mail className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan" aria-hidden="true" />
                  <span className="break-all">{SITE.emails.primary}</span>
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${SITE.emails.hr}`}
                  className="group inline-flex items-start gap-2.5 text-[15px] text-white/60 transition-colors hover:text-white"
                >
                  <Mail className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan/60" aria-hidden="true" />
                  <span className="break-all">{SITE.emails.hr}</span>
                </a>
              </li>
            </ul>
            <p className="mt-4 text-[13px] leading-relaxed text-white/40">
              HR address as supplied by the company.
            </p>
            <a
              href={SITE.mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex items-start gap-2.5 text-[14px] leading-relaxed text-white/65 transition-colors hover:text-white"
            >
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-cyan" aria-hidden="true" />
              <span>
                {SITE.address.line1}
                <br />
                {SITE.address.line2}
                <br />
                {SITE.address.city}
              </span>
            </a>
            <Link
              to="/quote"
              className="mt-6 inline-flex rounded-full bg-white px-5 py-2.5 text-[13.5px] font-semibold text-brand-navy transition-colors hover:bg-brand-ice"
            >
              Request a quotation
            </Link>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-5 border-t border-white/10 pt-7 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[13px] text-white/45">
            © {year} {SITE.name}. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <Link to="/privacy" className="text-[13px] text-white/50 hover:text-white">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-[13px] text-white/50 hover:text-white">
              Terms & Conditions
            </Link>
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="inline-flex items-center gap-1.5 text-[13px] text-white/50 transition-colors hover:text-white"
            >
              Back to top
              <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}