import { cn } from "@/lib/utils";

export default function SectionHeading({ eyebrow, title, intro, align = "left", tone = "dark", className }) {
  const light = tone === "light";
  return (
    <div
      className={cn(
        "max-w-3xl",
        align === "center" && "mx-auto text-center",
        className
      )}
    >
      {eyebrow && (
        <p className={cn("eyebrow flex items-center gap-3", align === "center" && "justify-center")}>
          <span className={cn("h-px w-8", light ? "bg-white/40" : "bg-brand-blue/60")} />
          <span className={light ? "text-white/60" : undefined}>{eyebrow}</span>
        </p>
      )}
      <h2 className={cn("display-lg mt-4", light ? "text-white" : "text-brand-navy")}>{title}</h2>
      {intro && (
        <p className={cn("mt-5 text-[17px] leading-[1.7]", light ? "text-white/65" : "text-brand-slate")}>
          {intro}
        </p>
      )}
    </div>
  );
}