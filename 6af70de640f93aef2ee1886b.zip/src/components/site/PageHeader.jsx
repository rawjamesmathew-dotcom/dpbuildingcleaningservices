import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export default function PageHeader({ eyebrow, title, intro, children, className }) {
  return (
    <section
      className={cn(
        "relative isolate overflow-hidden bg-brand-navy pb-14 pt-28 sm:pb-20 sm:pt-32 lg:pt-36",
        className
      )}
    >
      <div className="pointer-events-none absolute -right-24 -top-24 h-[380px] w-[380px] rounded-full bg-brand-blue/25 blur-[120px]" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.14] [background-image:linear-gradient(rgba(255,255,255,0.3)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.3)_1px,transparent_1px)] [background-size:72px_72px]" />

      <div className="shell relative">
        <nav aria-label="Breadcrumb" className="mb-7 flex items-center gap-2 text-[12px] text-white/45">
          <Link to="/" className="transition-colors hover:text-white">
            Home
          </Link>
          <span aria-hidden="true">/</span>
          <span className="text-white/70">{eyebrow}</span>
        </nav>
        <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-brand-cyan">
          <span className="h-px w-10 bg-brand-cyan/70" />
          {eyebrow}
        </p>
        <h1 className="display-lg mt-5 max-w-3xl text-white">{title}</h1>
        {intro && <p className="mt-6 max-w-2xl text-[16.5px] leading-[1.75] text-white/65">{intro}</p>}
        {children && <div className="mt-9">{children}</div>}
      </div>
    </section>
  );
}