import { Link } from "@tanstack/react-router";
import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { IMAGES, SITE } from "@/lib/siteContent";
import useReducedMotionSafe from "@/lib/useReducedMotionSafe";

export default function Hero() {
  const ref = useRef(null);
  const reduce = useReducedMotionSafe();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "14%"]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0.35]);

  return (
    <section
      ref={ref}
      className="relative isolate flex min-h-[100svh] flex-col justify-end overflow-hidden bg-brand-navy"
      aria-labelledby="hero-heading"
    >
      <motion.div style={reduce ? undefined : { y }} className="absolute inset-0 -z-10">
        <Image
          src={IMAGES.hero}
          alt="A modern glass office lobby with polished stone floors and a cleaning specialist at work"
          className="h-full w-full object-cover"
          fittingType="fill"
          focalPointX={0.55}
          focalPointY={0.5}
        />
      </motion.div>

      <div className="absolute inset-0 -z-10 bg-[linear-gradient(105deg,rgba(7,29,59,0.94)_0%,rgba(7,29,59,0.82)_38%,rgba(7,29,59,0.42)_70%,rgba(7,29,59,0.72)_100%)]" />
      <div className="absolute inset-x-0 bottom-0 -z-10 h-56 bg-gradient-to-t from-brand-navy to-transparent" />

      <div className="pointer-events-none absolute right-[6%] top-[22%] -z-10 hidden h-40 w-40 rounded-full border border-white/15 bg-white/5 backdrop-blur-md lg:block lg:animate-float-slow" />
      <div className="pointer-events-none absolute right-[18%] top-[42%] -z-10 hidden h-16 w-16 rotate-12 rounded-2xl border border-brand-cyan/30 bg-brand-cyan/10 backdrop-blur-sm lg:block" />

      <motion.div
        style={reduce ? undefined : { opacity: fade }}
        className="shell relative w-full pb-16 pt-40 sm:pb-20 sm:pt-44"
      >
        <div className="max-w-4xl">
          <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-brand-cyan">
            <span className="h-px w-10 bg-brand-cyan/70" />
            {SITE.category}
          </p>

          <h1 id="hero-heading" className="mt-6 text-white">
            {["A Cleaner Space.", "A Better Standard."].map((line, i) => (
              <span key={line} className="block overflow-hidden">
                <motion.span
                  initial={reduce ? false : { y: "110%", clipPath: "inset(0 0 100% 0)" }}
                  animate={{ y: "0%", clipPath: "inset(0 0 0% 0)" }}
                  transition={{ duration: 1, delay: 0.12 + i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                  className="display-xl block"
                >
                  {line}
                </motion.span>
              </span>
            ))}
          </h1>

          <motion.p
            initial={reduce ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="mt-7 max-w-xl text-[17px] leading-[1.7] text-white/75 sm:text-[19px]"
          >
            Professional cleaning for offices, buildings and shared spaces — alongside home works
            and repairs. Tell us about the property and our team will review the requirement and
            prepare a quotation.
          </motion.p>

          <motion.div
            initial={reduce ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.65, ease: [0.22, 1, 0.36, 1] }}
            className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4"
          >
            <Link
              to="/services"
              className="group inline-flex items-center justify-center gap-2.5 rounded-full bg-white px-7 py-4 text-[14.5px] font-semibold text-brand-navy transition-all duration-300 hover:bg-brand-cyan hover:text-brand-navy active:scale-[0.985]"
            >
              Explore Services
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
            </Link>
            <Link
              to="/quote"
              className="group inline-flex items-center justify-center gap-2.5 rounded-full border border-white/30 bg-white/10 px-7 py-4 text-[14.5px] font-semibold text-white backdrop-blur-md transition-all duration-300 hover:border-white/60 hover:bg-white/20 active:scale-[0.985]"
            >
              Get a Free Quote
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </motion.div>
        </div>

        <div className="mt-14 flex flex-wrap items-center gap-x-8 gap-y-3 border-t border-white/15 pt-6">
          {["Office cleaning", "Building cleaning", "Glass & facade", "Floor care"].map((item) => (
            <span key={item} className="text-[12px] font-medium uppercase tracking-[0.18em] text-white/45">
              {item}
            </span>
          ))}
        </div>
      </motion.div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-brand-cyan/0 via-brand-cyan/60 to-brand-cyan/0" />
    </section>
  );
}