import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import ServicesGrid from "@/components/site/ServicesGrid";
import FinalCta from "@/components/site/FinalCta";
import Reveal from "@/components/site/Reveal";
import { getPublicServices } from "@/lib/content-fns";

export const Route = createFileRoute("/_site/services/")({
  component: ServicesPage,
  loader: () => getPublicServices(),
  head: () => ({
    meta: [
      { title: "Cleaning & Building Services | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "Office cleaning, building cleaning, glass and facade cleaning, floor care, deep cleaning, post-construction cleaning and home works and repairs — each scoped and quoted individually.",
      },
      { property: "og:title", content: "Cleaning & Building Services" },
      {
        property: "og:description",
        content: "The services Deshani Prasang Building Services provides, explained clearly.",
      },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
});

function ServicesPage() {
  const services = Route.useLoaderData();
  return (
    <>
      <PageHeader
        eyebrow="Services"
        title="Seven services. One way of working."
        intro="Every service below is scoped with you before it starts: the areas, the frequency, the standard and the access arrangements. What is listed is what gets delivered."
      />

      <section className="bg-white py-16 sm:py-24">
        <div className="shell">
          <Reveal className="mb-10 rounded-2xl border border-brand-line bg-brand-mist p-5 sm:p-6">
            <p className="text-[13.5px] leading-relaxed text-brand-slate">
              <span className="font-semibold text-brand-navy">Note on scope:</span> inclusions shown
              for each service are the areas we plan around. Final inclusions, materials and
              frequency are confirmed in your quotation. No pricing is calculated on this website.
            </p>
          </Reveal>
          <ServicesGrid services={services} />
          <div className="mt-12 flex flex-col items-start justify-between gap-5 rounded-2xl border border-brand-line p-6 sm:flex-row sm:items-center">
            <p className="max-w-xl text-[14.5px] leading-relaxed text-brand-slate">
              Not sure which service fits? Describe the property and what needs attention — our team
              will advise on the right scope.
            </p>
            <Link
              to="/quote"
              className="group inline-flex shrink-0 items-center gap-2 rounded-full border border-brand-navy px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:bg-brand-navy hover:text-white"
            >
              Request a quotation
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      <FinalCta />
    </>
  );
}