import { useEffect, useState } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import useReducedMotionSafe from "@/lib/useReducedMotionSafe";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { NAV_LINKS } from "@/lib/siteContent";
import BrandMark from "@/components/site/BrandMark";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();
  const reduce = useReducedMotionSafe();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (to) => (to === "/" ? pathname === "/" : pathname.startsWith(to));

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div
        className={cn(
          "border-b bg-white transition-shadow duration-300",
          scrolled
            ? "border-brand-line shadow-[0_18px_44px_-32px_rgba(7,29,59,0.6)]"
            : "border-brand-line/70"
        )}
      >
        <div className="shell flex h-[68px] items-center justify-between gap-4">
          <BrandMark onClick={() => setOpen(false)} />

          <nav aria-label="Main" className="hidden lg:block">
            <ul className="flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className={cn(
                      "relative block px-3.5 py-2 text-[13.5px] font-medium tracking-[0.01em] transition-colors",
                      isActive(link.to)
                        ? "text-brand-navy"
                        : "text-brand-slate hover:text-brand-blue"
                    )}
                  >
                    {link.label}
                    <span
                      className={cn(
                        "absolute inset-x-3.5 -bottom-[9px] h-[2px] rounded-full transition-opacity",
                        isActive(link.to) ? "bg-brand-blue opacity-100" : "opacity-0"
                      )}
                    />
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-2">
            <Link
              to="/quote"
              className="hidden items-center gap-1.5 rounded-lg bg-brand-navy px-5 py-2.5 text-[13px] font-semibold text-white transition-colors hover:bg-brand-blue sm:inline-flex"
            >
              Get a quote
              <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="grid h-10 w-10 place-items-center rounded-lg border border-brand-line bg-white text-brand-navy transition-colors hover:border-brand-blue lg:hidden"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={reduce ? false : { opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduce ? undefined : { opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            className="max-h-[calc(100svh-68px)] overflow-y-auto border-b border-brand-line bg-white shadow-[0_30px_70px_-40px_rgba(7,29,59,0.8)] lg:hidden"
          >
            <div className="shell py-4">
              <ul className="flex flex-col">
                {NAV_LINKS.map((link) => (
                  <li key={link.to}>
                    <Link
                      to={link.to}
                      className={cn(
                        "flex items-center justify-between rounded-lg px-4 py-3.5 text-[15px] font-medium transition-colors",
                        isActive(link.to)
                          ? "bg-brand-ice text-brand-navy"
                          : "text-brand-slate hover:bg-brand-mist hover:text-brand-navy"
                      )}
                    >
                      {link.label}
                      <ArrowUpRight className="h-4 w-4 opacity-40" aria-hidden="true" />
                    </Link>
                  </li>
                ))}
              </ul>
              <Link
                to="/quote"
                className="mt-2 flex items-center justify-center gap-2 rounded-lg bg-brand-navy px-4 py-3.5 text-[15px] font-semibold text-white"
              >
                Get a free quote
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}