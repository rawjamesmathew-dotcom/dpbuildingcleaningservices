import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Mail } from "lucide-react";
import { Image } from "@/components/ui/image";
import { IMAGES, SITE } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";

export default function FinalCta() {
  return (
    <section className="relative isolate overflow-hidden bg-brand-navy py-20 sm:py-28">
      <div className="absolute inset-0 -z-10 opacity-40">
        <Image
          src={IMAGES.cta}
          alt="A pristine empty office corridor at dawn"
          className="h-full w-full object-cover"
          fittingType="fill"
        />
      </div>
      <div className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,rgba(7,29,59,0.97)_0%,rgba(7,29,59,0.86)_55%,rgba(7,29,59,0.6)_100%)]" />

      <div className="shell relative">
        <Reveal className="max-w-3xl">
          <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-brand-cyan">
            <span className="h-px w-10 bg-brand-cyan/70" />
            Next step
          </p>
          <h2 className="display-lg mt-5 text-white">
            Tell us about the building.
            <br className="hidden sm:block" /> We&rsquo;ll take it from there.
          </h2>
          <p className="mt-6 max-w-xl text-[16.5px] leading-[1.75] text-white/70">
            Share the property type, areas and preferred schedule. Our team reviews every request
            and comes back with the next steps and a quotation for the agreed scope.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Link
              to="/quote"
              className="group inline-flex items-center justify-center gap-2.5 rounded-full bg-white px-7 py-4 text-[14.5px] font-semibold text-brand-navy transition-all duration-300 hover:bg-brand-cyan active:scale-[0.985]"
            >
              Request a quotation
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
            <a
              href={`mailto:${SITE.emails.primary}`}
              className="inline-flex items-center justify-center gap-2.5 rounded-full border border-white/25 px-7 py-4 text-[14.5px] font-semibold text-white transition-colors hover:border-white/60 hover:bg-white/10"
            >
              <Mail className="h-4 w-4" aria-hidden="true" />
              Email our team
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}