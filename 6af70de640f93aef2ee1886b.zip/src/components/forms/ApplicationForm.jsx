const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, FileText } from "lucide-react";

import { submitJobApplication } from "@/lib/server-fns";
import { SITE } from "@/lib/siteContent";
import { Consent, Field, Honeypot, Input, Select, SubmitButton, Textarea } from "@/components/forms/fields";

const POSITIONS = [
  "Cleaning operative",
  "Team supervisor",
  "Maintenance / repairs",
  "Administration",
  "General application",
];

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const EMPTY = {
  name: "",
  email: "",
  phone: "",
  position: POSITIONS[0],
  experience: "",
  message: "",
  consent: false,
  honeypot: "",
};

export default function ApplicationForm() {
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");
  const submit = useServerFn(submitJobApplication);

  const update = (key) => (event) => {
    const value = event.target.type === "checkbox" ? event.target.checked : event.target.value;
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    if (status === "submitting") return;

    const next = {};
    if (values.name.trim().length < 2) next.name = "Please enter your name.";
    if (!EMAIL_RE.test(values.email.trim())) next.email = "Please enter a valid email address.";
    if (!values.consent) next.consent = "Please confirm the privacy notice to continue.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setStatus("submitting");
    setMessage("");

    try {
      let cv_uri = "";
      if (file) {
        const uploaded = await db.integrations.Core.UploadPrivateFile({ file });
        cv_uri = uploaded?.file_uri ?? "";
      }
      const result = await submit({ data: { ...values, cv_uri } });
      if (result?.ok) {
        setStatus("success");
      } else {
        setStatus("error");
        setMessage(result?.message || "We could not send your application. Please try again.");
      }
    } catch (error) {
      setStatus("error");
      setMessage("Something went wrong while sending your application. Please try again or email HR.");
    }
  };

  if (status === "success") {
    return (
      <div className="rounded-[26px] border border-brand-line bg-white p-8">
        <span className="grid h-12 w-12 place-items-center rounded-full bg-brand-ice text-brand-blue">
          <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
        </span>
        <h2 className="display-md mt-6 text-brand-navy">Application received.</h2>
        <p className="mt-3 text-[15px] leading-relaxed text-brand-slate">
          Thank you — your application has been logged. If your experience matches what we need, our
          team will contact you using the details you provided.
        </p>
        <button
          type="button"
          onClick={() => {
            setValues(EMPTY);
            setFile(null);
            setStatus("idle");
          }}
          className="mt-6 rounded-full border border-brand-line px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue"
        >
          Submit another application
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="rounded-[26px] border border-brand-line bg-white p-6 sm:p-8">
      <Honeypot value={values.honeypot} onChange={update("honeypot")} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" htmlFor="j-name" required error={errors.name}>
          <Input id="j-name" autoComplete="name" value={values.name} onChange={update("name")} placeholder="Your name" />
        </Field>
        <Field label="Email" htmlFor="j-email" required error={errors.email}>
          <Input id="j-email" type="email" autoComplete="email" value={values.email} onChange={update("email")} placeholder="you@email.com" />
        </Field>
        <Field label="Phone" htmlFor="j-phone">
          <Input id="j-phone" type="tel" autoComplete="tel" value={values.phone} onChange={update("phone")} placeholder="Include country code" />
        </Field>
        <Field label="Role of interest" htmlFor="j-position" required>
          <Select id="j-position" value={values.position} onChange={update("position")}>
            {POSITIONS.map((position) => (
              <option key={position} value={position}>
                {position}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Experience summary" htmlFor="j-experience">
          <Input id="j-experience" value={values.experience} onChange={update("experience")} placeholder="e.g. 3 years commercial cleaning" />
        </Field>
        <Field label="CV" htmlFor="j-cv" hint="PDF or Word document, up to 5 MB. Stored privately.">
          <label
            htmlFor="j-cv"
            className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-brand-line bg-brand-mist px-4 py-3 text-[13.5px] text-brand-slate transition-colors hover:border-brand-blue"
          >
            <FileText className="h-4 w-4 text-brand-blue" aria-hidden="true" />
            {file ? file.name : "Attach your CV"}
          </label>
          <input
            id="j-cv"
            type="file"
            accept=".pdf,.doc,.docx"
            className="sr-only"
            onChange={(event) => {
              const chosen = event.target.files?.[0] ?? null;
              if (chosen && chosen.size > 5 * 1024 * 1024) {
                setErrors((prev) => ({ ...prev, cv: "Please choose a file under 5 MB." }));
                setFile(null);
                return;
              }
              setFile(chosen);
            }}
          />
        </Field>
      </div>

      <div className="mt-5">
        <Field label="A short note" htmlFor="j-message">
          <Textarea id="j-message" value={values.message} onChange={update("message")} placeholder="Tell us briefly why you are applying." />
        </Field>
        {errors.cv && <p className="mt-2 text-[12.5px] font-medium text-red-600">{errors.cv}</p>}
      </div>

      <div className="mt-5">
        <Consent id="j-consent" checked={values.consent} onChange={update("consent")} error={errors.consent}>
          I agree that {SITE.name} may store and review my application details for recruitment
          purposes, as described in the{" "}
          <a href="/privacy" className="font-semibold text-brand-blue underline">
            privacy policy
          </a>
          .
        </Consent>
      </div>

      {status === "error" && (
        <p role="alert" className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-[13.5px] text-red-700">
          {message} You can also email{" "}
          <a href={`mailto:${SITE.emails.hr}`} className="font-semibold underline">
            {SITE.emails.hr}
          </a>
          .
        </p>
      )}

      <div className="mt-7">
        <SubmitButton loading={status === "submitting"}>
          {status === "submitting" ? "Sending application" : "Send application"}
        </SubmitButton>
      </div>
    </form>
  );
}