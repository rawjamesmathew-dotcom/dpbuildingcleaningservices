import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Info } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import GalleryGrid from "@/components/site/GalleryGrid";
import { getPublicProjects } from "@/lib/content-fns";

export const Route = createFileRoute("/_site/projects")({
  component: ProjectsPage,
  loader: () => getPublicProjects(),
  head: () => ({
    meta: [
      { title: "Project Gallery | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "A gallery of the building environments our cleaning, facade, floor care and repair services are designed for. Illustrative references only.",
      },
      { property: "og:title", content: "Project Gallery" },
      {
        property: "og:description",
        content: "Reference images of the spaces our services cover.",
      },
    ],
    links: [{ rel: "canonical", href: "/projects" }],
  }),
});

function ProjectsPage() {
  const projects = Route.useLoaderData();
  return (
    <>
      <PageHeader
        eyebrow="Projects"
        title="The spaces we look after."
        intro="Filter by environment type to see the kind of work each service is built for. Open any image to view it larger."
      />

      <section className="bg-white py-16 sm:py-24">
        <div className="shell">
          <div className="mb-10 flex items-start gap-3 rounded-2xl border border-brand-line bg-brand-mist p-5">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-brand-blue" aria-hidden="true" />
            <p className="text-[13.5px] leading-relaxed text-brand-slate">
              <span className="font-semibold text-brand-navy">These are illustrative images.</span>{" "}
              They show the environments our services are designed for and are not photographs of
              completed company projects. Approved project photography will replace them once the
              company supplies it with permission to publish.
            </p>
          </div>

          <GalleryGrid items={projects} withFilters />

          <div className="mt-14 flex flex-col items-start justify-between gap-5 rounded-[24px] border border-brand-line bg-brand-navy p-8 sm:flex-row sm:items-center">
            <div>
              <h2 className="display-md text-white">Have a property that needs this standard?</h2>
              <p className="mt-2 max-w-xl text-[14.5px] text-white/60">
                Send the details and our team will review the requirement.
              </p>
            </div>
            <Link
              to="/quote"
              className="group inline-flex shrink-0 items-center gap-2 rounded-full bg-white px-6 py-3.5 text-[14px] font-semibold text-brand-navy transition-colors hover:bg-brand-cyan"
            >
              Get a free quote
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}