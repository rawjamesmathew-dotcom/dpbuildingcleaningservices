import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { Image } from "@/components/ui/image";
import { IMAGES } from "@/lib/siteContent";

export default function BrandMark({ tone = "dark", className, onClick }) {
  const light = tone === "light";
  return (
    <Link
      to="/"
      onClick={onClick}
      aria-label="Deshani Prasang Building Services — home"
      className={cn("group flex items-center gap-3", className)}
    >
      <span
        className={cn(
          "relative h-11 w-11 shrink-0 overflow-hidden rounded-xl bg-white ring-1",
          light ? "ring-white/25" : "ring-brand-line",
          "shadow-[0_10px_30px_-18px_rgba(7,29,59,0.7)]"
        )}
      >
        <Image
          src={IMAGES.logo}
          alt="Deshani Prasang Building Services logo"
          fittingType="fill"
          className="h-full w-full"
        />
      </span>
      <span className="flex flex-col leading-none">
        <span
          className={cn(
            "font-display text-[15px] font-extrabold tracking-[-0.02em] sm:text-base",
            light ? "text-white" : "text-brand-navy"
          )}
        >
          Deshani Prasang
        </span>
        <span
          className={cn(
            "mt-1 text-[9.5px] font-semibold uppercase tracking-[0.24em]",
            light ? "text-white/60" : "text-brand-slate"
          )}
        >
          Building Services
        </span>
      </span>
    </Link>
  );
}