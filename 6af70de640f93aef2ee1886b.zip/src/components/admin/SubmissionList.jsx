const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";

import { cn } from "@/lib/utils";

const STATUS_TONE = {
  new: "bg-brand-blue text-white",
  in_progress: "bg-amber-100 text-amber-800",
  reviewing: "bg-amber-100 text-amber-800",
  shortlisted: "bg-purple-100 text-purple-800",
  quoted: "bg-purple-100 text-purple-800",
  scheduled: "bg-emerald-100 text-emerald-800",
  closed: "bg-brand-mist text-brand-slate",
};

export default function SubmissionList({ entity, title, description, fields, statusOptions, fileField, fileLabel }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [openId, setOpenId] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const page = await db.entities[entity].list("-created_date", 200);
      setItems(Array.isArray(page) ? page : page?.items ?? []);
      setError("");
    } catch (err) {
      setError("Could not load records. Please refresh.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [entity]);

  const changeStatus = async (id, status) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, status } : item)));
    await db.entities[entity].update(id, { status });
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this record permanently?")) return;
    await db.entities[entity].delete(id);
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const openFile = async (uri) => {
    const { signed_url } = await db.integrations.Core.CreateFileSignedUrl({ file_uri: uri });
    if (signed_url) window.open(signed_url, "_blank", "noopener");
  };

  return (
    <div>
      <header className="mb-7">
        <h1 className="display-md text-brand-navy">{title}</h1>
        <p className="mt-2 max-w-2xl text-[14px] text-brand-slate">{description}</p>
      </header>

      {error && (
        <p className="mb-4 rounded-xl border border-red-200 bg-red-50 p-4 text-[13px] text-red-700">
          {error}
        </p>
      )}

      {loading ? (
        <div className="grid place-items-center rounded-2xl border border-brand-line bg-white py-16">
          <span className="h-6 w-6 animate-spin rounded-full border-2 border-brand-line border-t-brand-blue" />
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-brand-line bg-white py-16 text-center">
          <p className="text-[14px] text-brand-slate">No records yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => {
            const open = openId === item.id;
            return (
              <article key={item.id} className="rounded-2xl border border-brand-line bg-white">
                <div className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5">
                  <div className="min-w-0">
                    <p className="truncate font-display text-[15px] font-bold text-brand-navy">
                      {item.name} <span className="font-body text-[12.5px] font-normal text-brand-slate">· {item.email}</span>
                    </p>
                    <p className="mt-1 text-[12px] text-brand-slate">
                      {new Date(item.created_date).toLocaleString("en-GB", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}
                      {item.service ? ` · ${item.service}` : ""}
                      {item.position ? ` · ${item.position}` : ""}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={cn(
                        "rounded-full px-2.5 py-1 text-[10.5px] font-semibold uppercase tracking-[0.1em]",
                        STATUS_TONE[item.status] ?? "bg-brand-mist text-brand-slate"
                      )}
                    >
                      {String(item.status ?? "new").replace("_", " ")}
                    </span>
                    <select
                      aria-label="Update status"
                      value={item.status ?? "new"}
                      onChange={(event) => changeStatus(item.id, event.target.value)}
                      className="rounded-lg border border-brand-line bg-white px-2.5 py-1.5 text-[12.5px] text-brand-navy"
                    >
                      {statusOptions.map((status) => (
                        <option key={status} value={status}>
                          {status.replace("_", " ")}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => setOpenId(open ? null : item.id)}
                      className="rounded-lg border border-brand-line px-3 py-1.5 text-[12.5px] font-medium text-brand-navy hover:border-brand-blue"
                    >
                      {open ? "Hide" : "View"}
                    </button>
                    <button
                      type="button"
                      onClick={() => remove(item.id)}
                      className="rounded-lg border border-red-200 px-3 py-1.5 text-[12.5px] font-medium text-red-600 hover:bg-red-50"
                    >
                      Delete
                    </button>
                  </div>
                </div>

                {open && (
                  <div className="border-t border-brand-line bg-brand-mist/50 p-5">
                    <dl className="grid gap-4 sm:grid-cols-2">
                      {fields.map((field) => {
                        const value = item[field.key];
                        if (!value) return null;
                        return (
                          <div key={field.key} className={field.wide ? "sm:col-span-2" : undefined}>
                            <dt className="text-[10.5px] font-semibold uppercase tracking-[0.16em] text-brand-slate">
                              {field.label}
                            </dt>
                            <dd className="mt-1 whitespace-pre-wrap text-[13.5px] leading-relaxed text-brand-navy">
                              {String(value)}
                            </dd>
                          </div>
                        );
                      })}
                    </dl>
                    {fileField && item[fileField] && (
                      <button
                        type="button"
                        onClick={() => openFile(item[fileField])}
                        className="mt-4 rounded-lg bg-brand-navy px-4 py-2 text-[12.5px] font-semibold text-white"
                      >
                        Open {fileLabel ?? "attachment"}
                      </button>
                    )}
                    <a
                      href={`mailto:${item.email}`}
                      className="mt-4 ml-2 inline-flex rounded-lg border border-brand-line bg-white px-4 py-2 text-[12.5px] font-semibold text-brand-navy"
                    >
                      Reply by email
                    </a>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}