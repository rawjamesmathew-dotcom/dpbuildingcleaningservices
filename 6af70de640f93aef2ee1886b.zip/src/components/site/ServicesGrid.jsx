import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { SERVICES } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";

export default function ServicesGrid({ services = SERVICES, showAll = true }) {
  const items = showAll ? services : services.slice(0, 3);

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((service, i) => (
        <Reveal key={service.slug} delay={(i % 3) * 0.07}>
          <Link
            to="/services/$slug"
            params={{ slug: service.slug }}
            className="lift group flex h-full flex-col overflow-hidden rounded-[22px] border border-brand-line bg-white"
          >
            <div className="relative aspect-[4/3] overflow-hidden bg-brand-ice">
              <Image
                src={service.image}
                alt={`${service.name} — ${service.summary}`}
                className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.045]"
                fittingType="fill"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/45 via-transparent to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-90" />
              <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-brand-navy backdrop-blur">
                {service.category}
              </span>
            </div>
            <div className="flex flex-1 flex-col p-6">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-[19px] font-bold tracking-[-0.02em] text-brand-navy">
                  {service.name}
                </h3>
                <span className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-brand-line text-brand-blue transition-all duration-300 group-hover:border-brand-blue group-hover:bg-brand-blue group-hover:text-white">
                  <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </span>
              </div>
              <p className="mt-3 text-[14.5px] leading-relaxed text-brand-slate">{service.summary}</p>
              <span className="mt-auto pt-5 text-[12px] font-semibold uppercase tracking-[0.16em] text-brand-blue">
                View service
              </span>
            </div>
          </Link>
        </Reveal>
      ))}
    </div>
  );
}