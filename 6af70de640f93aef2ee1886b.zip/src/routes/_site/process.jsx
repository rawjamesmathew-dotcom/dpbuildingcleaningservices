import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, ShieldCheck } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import ProcessSteps from "@/components/site/ProcessSteps";
import SectionHeading from "@/components/site/SectionHeading";
import { PROCESS_STEPS } from "@/lib/siteContent";

export const Route = createFileRoute("/_site/process")({
  component: ProcessPage,
  head: () => ({
    meta: [
      { title: "Our Process | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "From enquiry to completed work: how a request is reviewed, quoted, scheduled and delivered by Deshani Prasang Building Services.",
      },
      { property: "og:title", content: "Our Process" },
      { property: "og:description", content: "What happens after you send a request." },
    ],
    links: [{ rel: "canonical", href: "/process" }],
  }),
});

function ProcessPage() {
  return (
    <>
      <PageHeader
        eyebrow="Process"
        title="What happens after you send a request."
        intro="No automated pricing and no implied booking. Every enquiry is read by a person, clarified where needed, and answered with a quotation for a defined scope."
      />

      <ProcessSteps />

      <section className="bg-white py-20 sm:py-28">
        <div className="shell grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <SectionHeading
            eyebrow="Before work begins"
            title="Everything confirmed up front."
            intro="These are the points we settle with you before the first visit, so there are no surprises on either side."
          />
          <div className="space-y-4">
            {[
              {
                title: "Scope and inclusions",
                body: "Which areas are covered, what the standard is, and what is excluded from the price.",
              },
              {
                title: "Schedule and access",
                body: "Dates, times and how the team enters and secures the property, including out-of-hours arrangements.",
              },
              {
                title: "Contacts",
                body: "Who on your side is the point of contact, and how to reach ours if something needs attention.",
              },
              {
                title: "Change handling",
                body: "If the requirement changes after the quotation, we confirm whether the price is affected before proceeding.",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="flex items-start gap-4 rounded-2xl border border-brand-line bg-brand-mist/60 p-5"
              >
                <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-brand-blue" aria-hidden="true" />
                <div>
                  <h3 className="font-display text-[15.5px] font-bold text-brand-navy">{item.title}</h3>
                  <p className="mt-1.5 text-[14px] leading-relaxed text-brand-slate">{item.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-brand-mist py-16">
        <div className="shell flex flex-col items-start justify-between gap-6 rounded-[24px] border border-brand-line bg-white p-8 sm:flex-row sm:items-center">
          <div>
            <h2 className="display-md text-brand-navy">Step one is yours.</h2>
            <p className="mt-2 max-w-xl text-[15px] text-brand-slate">
              The first stage of the process — {PROCESS_STEPS[0].title.toLowerCase()} — takes a few
              minutes through the quote request form.
            </p>
          </div>
          <Link
            to="/quote"
            className="group inline-flex shrink-0 items-center gap-2 rounded-full bg-brand-navy px-6 py-3.5 text-[14px] font-semibold text-white transition-colors hover:bg-brand-blue"
          >
            Start a request
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
          </Link>
        </div>
      </section>
    </>
  );
}