import { cn } from "@/lib/utils";

const base =
  "w-full rounded-xl border border-brand-line bg-white px-4 py-3 text-[15px] text-brand-navy placeholder:text-brand-slate/50 transition-colors focus:border-brand-blue focus:outline-none focus:ring-2 focus:ring-brand-blue/20 disabled:opacity-60";

export function Field({ label, htmlFor, required, hint, error, children }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="flex items-center justify-between gap-2">
        <span className="text-[12.5px] font-semibold uppercase tracking-[0.12em] text-brand-navy">
          {label}
          {required && <span className="ml-1 text-brand-blue">*</span>}
        </span>
        <span className="text-[10.5px] uppercase tracking-[0.12em] text-brand-slate/60">
          {required ? "Required" : "Optional"}
        </span>
      </label>
      <div className="mt-2">{children}</div>
      {hint && !error && <p className="mt-1.5 text-[12px] text-brand-slate/70">{hint}</p>}
      {error && (
        <p role="alert" className="mt-1.5 text-[12.5px] font-medium text-red-600">
          {error}
        </p>
      )}
    </div>
  );
}

export function Input({ className, ...props }) {
  return <input className={cn(base, className)} {...props} />;
}

export function Textarea({ className, ...props }) {
  return <textarea className={cn(base, "min-h-[130px] resize-y", className)} {...props} />;
}

export function Select({ className, children, ...props }) {
  return (
    <select className={cn(base, "appearance-none bg-white pr-10", className)} {...props}>
      {children}
    </select>
  );
}

export function Consent({ id, checked, onChange, error, children }) {
  return (
    <div>
      <div className="flex items-start gap-3">
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={onChange}
          className="mt-1 h-4 w-4 shrink-0 rounded border-brand-line text-brand-blue focus:ring-brand-blue/30"
        />
        <label htmlFor={id} className="text-[13px] leading-relaxed text-brand-slate">
          {children}
        </label>
      </div>
      {error && (
        <p role="alert" className="mt-2 text-[12.5px] font-medium text-red-600">
          {error}
        </p>
      )}
    </div>
  );
}

export function SubmitButton({ loading, children, className }) {
  return (
    <button
      type="submit"
      disabled={loading}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full bg-brand-navy px-7 py-3.5 text-[14px] font-semibold text-white transition-all hover:bg-brand-blue disabled:cursor-not-allowed disabled:opacity-70",
        className
      )}
    >
      {loading && (
        <span
          aria-hidden="true"
          className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
        />
      )}
      {children}
    </button>
  );
}

export function Honeypot({ value, onChange }) {
  return (
    <div className="hidden" aria-hidden="true">
      <label htmlFor="company_website">Company website</label>
      <input
        id="company_website"
        name="company_website"
        tabIndex={-1}
        autoComplete="off"
        value={value}
        onChange={onChange}
      />
    </div>
  );
}