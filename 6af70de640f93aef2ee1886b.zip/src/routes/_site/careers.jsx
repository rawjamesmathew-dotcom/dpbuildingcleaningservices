import { createFileRoute } from "@tanstack/react-router";
import { Briefcase, Info } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import ApplicationForm from "@/components/forms/ApplicationForm";
import { SITE } from "@/lib/siteContent";

export const Route = createFileRoute("/_site/careers")({
  component: CareersPage,
  head: () => ({
    meta: [
      { title: "Careers | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "Send a general application to join the Deshani Prasang Building Services team. Current vacancies will be listed here when confirmed.",
      },
      { property: "og:title", content: "Careers" },
      { property: "og:description", content: "Applications are welcome for cleaning and repair roles." },
    ],
    links: [{ rel: "canonical", href: "/careers" }],
  }),
});

function CareersPage() {
  return (
    <>
      <PageHeader
        eyebrow="Careers"
        title="Work with us."
        intro="We keep an open application list for cleaning, supervision and maintenance roles. Applications are read by our team and kept for recruitment purposes only."
      />

      <section className="bg-brand-mist py-14 sm:py-20">
        <div className="shell grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-14">
          <div className="space-y-4">
            <div className="rounded-[22px] border border-brand-line bg-white p-6">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-ice text-brand-blue">
                  <Briefcase className="h-5 w-5" aria-hidden="true" />
                </span>
                <h2 className="font-display text-[16px] font-bold text-brand-navy">
                  Current vacancies
                </h2>
              </div>
              <p className="mt-3 text-[13.5px] leading-relaxed text-brand-slate">
                No specific vacancies are advertised at the moment. We do not list roles that do not
                exist — general applications are still welcome and are reviewed when a position
                opens.
              </p>
            </div>

            <div className="flex items-start gap-3 rounded-[22px] border border-brand-line bg-white p-6">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-brand-blue" aria-hidden="true" />
              <div>
                <h2 className="font-display text-[14.5px] font-bold text-brand-navy">
                  How applications are handled
                </h2>
                <p className="mt-2 text-[13px] leading-relaxed text-brand-slate">
                  Applications are stored privately and visible only to authorised administrators.
                  Your CV is not publicly accessible. You can ask for your application to be deleted
                  at any time by emailing{" "}
                  <a href={`mailto:${SITE.emails.hr}`} className="font-semibold text-brand-blue">
                    {SITE.emails.hr}
                  </a>
                  .
                </p>
              </div>
            </div>

            <div className="rounded-[22px] border border-brand-line bg-brand-navy p-6 text-white">
              <h2 className="font-display text-[15px] font-bold">What we look for</h2>
              <ul className="mt-3 space-y-2 text-[13px] text-white/65">
                <li>— Reliability and punctuality on scheduled visits.</li>
                <li>— Care and attention when working in occupied buildings.</li>
                <li>— Practical experience in cleaning or building maintenance.</li>
                <li>— Clear communication with clients and team members.</li>
              </ul>
            </div>
          </div>

          <div>
            <ApplicationForm />
          </div>
        </div>
      </section>
    </>
  );
}