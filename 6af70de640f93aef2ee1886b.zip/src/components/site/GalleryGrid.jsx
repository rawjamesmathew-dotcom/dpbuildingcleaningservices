import { useEffect, useState } from "react";
import { X, Maximize2 } from "lucide-react";
import { Image } from "@/components/ui/image";
import { PROJECTS } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";
import { cn } from "@/lib/utils";

export default function GalleryGrid({ items = PROJECTS, withFilters = false, className }) {
  const [filter, setFilter] = useState("All");
  const [active, setActive] = useState(null);

  const categories = ["All", ...Array.from(new Set(items.map((item) => item.category)))];
  const visible = filter === "All" ? items : items.filter((item) => item.category === filter);

  useEffect(() => {
    if (!active) return;
    const onKey = (event) => {
      if (event.key === "Escape") setActive(null);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [active]);

  return (
    <div className={className}>
      {withFilters && (
        <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Filter gallery by category">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setFilter(category)}
              aria-pressed={filter === category}
              className={cn(
                "rounded-full border px-4 py-2 text-[13px] font-medium transition-all duration-300",
                filter === category
                  ? "border-brand-navy bg-brand-navy text-white"
                  : "border-brand-line bg-white text-brand-slate hover:border-brand-blue hover:text-brand-blue"
              )}
            >
              {category}
            </button>
          ))}
        </div>
      )}

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((item, i) => (
          <Reveal key={item.title} delay={(i % 3) * 0.06}>
            <button
              type="button"
              onClick={() => setActive(item)}
              aria-label={`View ${item.title} larger`}
              className={cn(
                "group relative block w-full overflow-hidden rounded-[20px] border border-brand-line bg-brand-ice text-left",
                i === 0 ? "aspect-[4/5] sm:aspect-[4/3] lg:aspect-[4/5]" : "aspect-[4/3]"
              )}
            >
              <Image
                src={item.image}
                alt={item.description}
                className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.05]"
                fittingType="fill"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-brand-navy/85 via-brand-navy/10 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />
              <span className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-5">
                <span>
                  <span className="block text-[10px] font-semibold uppercase tracking-[0.2em] text-brand-cyan">
                    {item.category}
                  </span>
                  <span className="mt-1.5 block font-display text-[16px] font-semibold text-white">
                    {item.title}
                  </span>
                </span>
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-white/40 text-white opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
              </span>
              {item.illustrative && (
                <span className="absolute right-3 top-3 rounded-full bg-white/85 px-2.5 py-1 text-[9.5px] font-semibold uppercase tracking-[0.14em] text-brand-navy backdrop-blur">
                  Illustrative
                </span>
              )}
            </button>
          </Reveal>
        ))}
      </div>

      {visible.length === 0 && (
        <p className="rounded-2xl border border-brand-line bg-white p-8 text-center text-brand-slate">
          No images in this category yet.
        </p>
      )}

      {active && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={active.title}
          className="fixed inset-0 z-[70] flex items-center justify-center bg-brand-navy/95 p-4 backdrop-blur-sm"
          onClick={() => setActive(null)}
        >
          <div
            className="relative w-full max-w-4xl"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              type="button"
              autoFocus
              onClick={() => setActive(null)}
              aria-label="Close image viewer"
              className="absolute -top-12 right-0 grid h-10 w-10 place-items-center rounded-full border border-white/30 text-white transition-colors hover:bg-white hover:text-brand-navy"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
            <div className="overflow-hidden rounded-2xl border border-white/15 bg-brand-deep">
              <Image
                src={active.image}
                alt={active.description}
                className="block h-[62vh] w-full sm:h-[70vh]"
                fittingType="fit"
              />
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-display text-[17px] font-semibold text-white">{active.title}</p>
                <p className="mt-1 text-[13px] text-white/55">{active.description}</p>
              </div>
              {active.illustrative && (
                <span className="rounded-full border border-white/25 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/60">
                  Illustrative image
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}