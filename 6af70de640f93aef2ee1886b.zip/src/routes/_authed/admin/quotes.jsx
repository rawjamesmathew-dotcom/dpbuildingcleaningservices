import { createFileRoute } from "@tanstack/react-router";
import SubmissionList from "@/components/admin/SubmissionList";

export const Route = createFileRoute("/_authed/admin/quotes")({ component: QuotesPage });

function QuotesPage() {
  return (
    <SubmissionList
      entity="QuoteRequest"
      title="Quote requests"
      description="Quotation requests submitted through the website, including the property details supplied."
      statusOptions={["new", "quoted", "scheduled", "closed"]}
      fileField="image_uri"
      fileLabel="reference image"
      fields={[
        { key: "name", label: "Name" },
        { key: "email", label: "Email" },
        { key: "phone", label: "Phone" },
        { key: "company", label: "Company" },
        { key: "service", label: "Service requested" },
        { key: "building_type", label: "Property type" },
        { key: "property_size", label: "Area / size" },
        { key: "location", label: "Location" },
        { key: "preferred_date", label: "Preferred schedule" },
        { key: "requirements", label: "Requirements", wide: true },
      ]}
    />
  );
}