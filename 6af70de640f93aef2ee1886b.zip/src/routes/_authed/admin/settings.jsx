const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { SITE } from "@/lib/siteContent";

export const Route = createFileRoute("/_authed/admin/settings")({ component: SettingsAdmin });

const DEFAULTS = {
  company_name: SITE.name,
  tagline: SITE.description,
  primary_email: SITE.emails.primary,
  hr_email: SITE.emails.hr,
  phone: "",
  whatsapp: "",
  address: "",
  working_hours: "",
  hero_headline: "",
  hero_support: "",
  home_seo_title: "Deshani Prasang Building Services | Professional Building Cleaning",
  home_seo_description:
    "Discover professional building cleaning services from Deshani Prasang Building Services. Contact our team to discuss your cleaning requirements and request a quotation.",
};

const inputClass =
  "w-full rounded-xl border border-brand-line bg-white px-3.5 py-2.5 text-[13.5px] text-brand-navy focus:border-brand-blue focus:outline-none";

function SettingsAdmin() {
  const [form, setForm] = useState(DEFAULTS);
  const [recordId, setRecordId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const load = async () => {
      try {
        const page = await db.entities.SiteSettings.list("-created_date", 1);
        const first = (Array.isArray(page) ? page : page?.items ?? [])[0];
        if (first) {
          setRecordId(first.id);
          setForm({ ...DEFAULTS, ...Object.fromEntries(Object.entries(first).map(([k, v]) => [k, v ?? ""])) });
        }
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const save = async (event) => {
    event.preventDefault();
    if (saving) return;
    setSaving(true);
    setNotice("");
    const payload = { ...form };
    delete payload.id;
    delete payload.created_date;
    delete payload.updated_date;
    delete payload.created_by_id;
    try {
      if (recordId) {
        await db.entities.SiteSettings.update(recordId, payload);
      } else {
        const created = await db.entities.SiteSettings.create(payload);
        setRecordId(created?.id ?? null);
      }
      setNotice("Saved. The contact page and site details now use these values.");
    } catch (error) {
      setNotice("Could not save. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const field = (key) => ({
    value: form[key] ?? "",
    onChange: (event) => setForm({ ...form, [key]: event.target.value }),
  });

  return (
    <div>
      <header className="mb-6">
        <h1 className="display-md text-brand-navy">Site settings</h1>
        <p className="mt-2 max-w-2xl text-[14px] text-brand-slate">
          Contact details, working hours and homepage copy. Leave phone, WhatsApp, address and hours
          blank until the company confirms them — blank fields stay hidden on the website.
        </p>
      </header>

      {loading ? (
        <p className="text-[13px] text-brand-slate">Loading settings…</p>
      ) : (
        <form onSubmit={save} className="space-y-6">
          <section className="rounded-2xl border border-brand-line bg-white p-5 sm:p-6">
            <h2 className="font-display text-[15px] font-bold text-brand-navy">Contact details</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Primary email
                <input className={`${inputClass} mt-1.5`} type="email" {...field("primary_email")} />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                HR email
                <input className={`${inputClass} mt-1.5`} type="email" {...field("hr_email")} />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Phone (verified only)
                <input className={`${inputClass} mt-1.5`} {...field("phone")} placeholder="+971 …" />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                WhatsApp (verified only)
                <input className={`${inputClass} mt-1.5`} {...field("whatsapp")} placeholder="+971 …" />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Public address
                <input className={`${inputClass} mt-1.5`} {...field("address")} />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Working hours
                <input className={`${inputClass} mt-1.5`} {...field("working_hours")} placeholder="e.g. Mon–Sat, 8am–6pm" />
              </label>
            </div>
          </section>

          <section className="rounded-2xl border border-brand-line bg-white p-5 sm:p-6">
            <h2 className="font-display text-[15px] font-bold text-brand-navy">Homepage &amp; SEO</h2>
            <div className="mt-4 grid gap-4">
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Company name
                <input className={`${inputClass} mt-1.5`} {...field("company_name")} />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Short description
                <textarea className={`${inputClass} mt-1.5 min-h-[80px]`} {...field("tagline")} />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Homepage SEO title
                <input className={`${inputClass} mt-1.5`} {...field("home_seo_title")} />
              </label>
              <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
                Homepage SEO description
                <textarea className={`${inputClass} mt-1.5 min-h-[80px]`} {...field("home_seo_description")} />
              </label>
            </div>
          </section>

          {notice && <p className="rounded-xl bg-brand-ice p-3 text-[12.5px] text-brand-navy">{notice}</p>}

          <button
            type="submit"
            disabled={saving}
            className="inline-flex rounded-full bg-brand-navy px-6 py-3 text-[13.5px] font-semibold text-white disabled:opacity-60"
          >
            {saving ? "Saving" : "Save settings"}
          </button>
        </form>
      )}
    </div>
  );
}