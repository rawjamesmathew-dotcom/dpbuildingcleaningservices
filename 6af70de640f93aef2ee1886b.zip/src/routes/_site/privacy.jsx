import { createFileRoute, Link } from "@tanstack/react-router";
import PageHeader from "@/components/site/PageHeader";
import { SITE } from "@/lib/siteContent";

export const Route = createFileRoute("/_site/privacy")({
  component: PrivacyPage,
  head: () => ({
    meta: [
      { title: "Privacy Policy | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "How Deshani Prasang Building Services collects, uses and stores information submitted through this website.",
      },
      { property: "og:title", content: "Privacy Policy" },
      { property: "og:description", content: "How website information is handled." },
    ],
    links: [{ rel: "canonical", href: "/privacy" }],
  }),
});

const SECTIONS = [
  {
    title: "1. Information you send us",
    body: "When you use the contact, quote request or careers form, we collect the details you enter: your name, email address, phone number if provided, company name if provided, and the details of your requirement. Career applications may also include a CV you choose to upload.",
  },
  {
    title: "2. Why we collect it",
    body: "To respond to your enquiry, prepare a quotation for the scope you describe, arrange a service you request, or consider an application you submit. We do not sell or rent your information.",
  },
  {
    title: "3. How it is stored",
    body: "Form submissions are stored in a secured database and are visible only to authorised administrators of this website. Uploaded files are stored privately and are not publicly accessible.",
  },
  {
    title: "4. Who can see it",
    body: "Only authorised team members who need the information to respond to you or deliver a service. Contact details are not published to other website visitors.",
  },
  {
    title: "5. Retention",
    body: "Enquiries and quotations are kept only as long as needed for the relationship and any legal obligation. You can ask us to delete your information at any time.",
  },
  {
    title: "6. Your choices",
    body: "You may request a copy of the information we hold about you, ask for corrections, or ask for it to be deleted by emailing the address below.",
  },
  {
    title: "7. Cookies",
    body: "This website does not set advertising or analytics cookies of its own. If analytics or advertising tools are enabled later, this policy will be updated and, where required, consent will be requested before any tracking occurs.",
  },
  {
    title: "8. Contact",
    body: `Questions about this policy can be sent to ${SITE.emails.primary}.`,
  },
];

function PrivacyPage() {
  return (
    <>
      <PageHeader
        eyebrow="Privacy"
        title="Privacy Policy"
        intro="What happens to the information you submit through this website."
      />

      <section className="bg-white py-16 sm:py-24">
        <div className="shell max-w-3xl">
          <p className="rounded-2xl border border-brand-line bg-brand-mist p-5 text-[13px] leading-relaxed text-brand-slate">
            <span className="font-semibold text-brand-navy">Review note:</span> this policy describes
            how the website currently handles information. It must be reviewed against the
            company&rsquo;s registered jurisdiction and internal practices before publication, and
            updated whenever a new tool that collects data is added.
          </p>

          <div className="mt-10 space-y-8">
            {SECTIONS.map((section) => (
              <div key={section.title}>
                <h2 className="font-display text-[19px] font-bold tracking-[-0.02em] text-brand-navy">
                  {section.title}
                </h2>
                <p className="mt-2.5 text-[15.5px] leading-[1.75] text-brand-slate">{section.body}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-wrap gap-4 border-t border-brand-line pt-8">
            <Link to="/terms" className="text-[14px] font-semibold text-brand-blue hover:underline">
              Terms &amp; Conditions
            </Link>
            <Link to="/contact" className="text-[14px] font-semibold text-brand-blue hover:underline">
              Contact the team
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}