import { createFileRoute } from "@tanstack/react-router";
import SubmissionList from "@/components/admin/SubmissionList";

export const Route = createFileRoute("/_authed/admin/applications")({ component: ApplicationsPage });

function ApplicationsPage() {
  return (
    <SubmissionList
      entity="JobApplication"
      title="Applications"
      description="Career applications received through the website. CVs are stored privately and open through a time-limited link."
      statusOptions={["new", "reviewing", "shortlisted", "closed"]}
      fileField="cv_uri"
      fileLabel="CV"
      fields={[
        { key: "name", label: "Name" },
        { key: "email", label: "Email" },
        { key: "phone", label: "Phone" },
        { key: "position", label: "Role of interest" },
        { key: "experience", label: "Experience" },
        { key: "message", label: "Note", wide: true },
      ]}
    />
  );
}