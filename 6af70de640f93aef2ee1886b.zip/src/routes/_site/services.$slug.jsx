import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Check } from "lucide-react";
import { Image } from "@/components/ui/image";
import { SERVICES } from "@/lib/siteContent";
import { getPublicServices } from "@/lib/content-fns";
import Reveal from "@/components/site/Reveal";

export const Route = createFileRoute("/_site/services/$slug")({
  component: ServiceDetail,
  head: ({ params }) => {
    const service = SERVICES.find((item) => item.slug === params?.slug);
    return {
      meta: [
        { title: `${service ? service.name : "Service"} | Deshani Prasang Building Services` },
        {
          name: "description",
          content: service ? service.summary : "Cleaning and building services.",
        },
        { property: "og:title", content: service ? service.name : "Service" },
        {
          property: "og:description",
          content: service ? service.summary : "Cleaning and building services.",
        },
      ],
      links: [{ rel: "canonical", href: `/services/${params?.slug ?? ""}` }],
    };
  },
  loader: async ({ params }) => {
    const services = await getPublicServices();
    const service = services.find((item) => item.slug === params.slug);
    if (!service) throw notFound();
    return { service, services };
  },
});

function ServiceDetail() {
  const { service, services } = Route.useLoaderData();
  const others = services.filter((item) => item.slug !== service.slug).slice(0, 3);

  return (
    <>
      <section className="relative isolate overflow-hidden bg-brand-navy pb-16 pt-32 sm:pt-40">
        <div className="pointer-events-none absolute -right-20 top-0 h-[420px] w-[420px] rounded-full bg-brand-blue/25 blur-[120px]" />
        <div className="shell relative grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-end">
          <div>
            <nav aria-label="Breadcrumb" className="mb-7 flex flex-wrap items-center gap-2 text-[12px] text-white/45">
              <Link to="/" className="hover:text-white">
                Home
              </Link>
              <span aria-hidden="true">/</span>
              <Link to="/services" className="hover:text-white">
                Services
              </Link>
              <span aria-hidden="true">/</span>
              <span className="text-white/70">{service.name}</span>
            </nav>
            <p className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-brand-cyan">
              <span className="h-px w-10 bg-brand-cyan/70" />
              {service.category}
            </p>
            <h1 className="display-lg mt-5 text-white">{service.name}</h1>
            <p className="mt-6 max-w-xl text-[16.5px] leading-[1.75] text-white/70">
              {service.summary}
            </p>
          </div>
          <Reveal>
            <div className="overflow-hidden rounded-[22px] border border-white/15">
              <Image
                src={service.image}
                alt={`${service.name} — ${service.summary}`}
                className="h-[240px] w-full object-cover sm:h-[300px]"
                fittingType="fill"
              />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-24">
        <div className="shell grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <div>
            <h2 className="display-md text-brand-navy">About this service</h2>
            <p className="mt-5 text-[16.5px] leading-[1.75] text-brand-slate">{service.description}</p>

            <h3 className="mt-10 font-display text-[15px] font-bold uppercase tracking-[0.16em] text-brand-navy">
              What the service covers
            </h3>
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {service.includes.map((item) => (
                <li
                  key={item}
                  className="flex items-start gap-3 rounded-xl border border-brand-line bg-brand-mist/60 p-4 text-[14px] text-brand-navy"
                >
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-brand-blue" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
            <p className="mt-4 text-[12.5px] leading-relaxed text-brand-slate/80">
              Final inclusions are confirmed in your quotation before any work is scheduled.
            </p>
          </div>

          <aside className="h-fit rounded-[22px] border border-brand-line bg-brand-mist p-7">
            <p className="eyebrow">Suitable for</p>
            <p className="mt-3 text-[15px] leading-relaxed text-brand-navy">{service.suitableFor}</p>
            <div className="my-6 h-px w-full bg-brand-line" />
            <p className="eyebrow">Next step</p>
            <p className="mt-3 text-[14px] leading-relaxed text-brand-slate">
              Send the property details and we will review the requirement and prepare a quotation.
              A quotation is a proposal — nothing is scheduled until both sides confirm.
            </p>
            <Link
              to="/quote"
              className="group mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand-navy px-6 py-3.5 text-[14px] font-semibold text-white transition-colors hover:bg-brand-blue"
            >
              Request this service
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
            </Link>
            <Link
              to="/contact"
              className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full border border-brand-line bg-white px-6 py-3.5 text-[14px] font-semibold text-brand-navy transition-colors hover:border-brand-blue"
            >
              Ask a question
            </Link>
          </aside>
        </div>
      </section>

      <section className="border-t border-brand-line bg-brand-mist py-16 sm:py-20">
        <div className="shell">
          <div className="flex items-end justify-between gap-6">
            <h2 className="display-md text-brand-navy">Other services</h2>
            <Link
              to="/services"
              className="group inline-flex items-center gap-2 text-[13px] font-semibold text-brand-blue"
            >
              All services
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </div>
          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {others.map((item) => (
              <Link
                key={item.slug}
                to="/services/$slug"
                params={{ slug: item.slug }}
                className="lift group overflow-hidden rounded-[20px] border border-brand-line bg-white"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <Image
                    src={item.image}
                    alt={item.name}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    fittingType="fill"
                  />
                </div>
                <div className="p-5">
                  <h3 className="font-display text-[16px] font-bold text-brand-navy">{item.name}</h3>
                  <p className="mt-2 text-[13px] leading-relaxed text-brand-slate">{item.summary}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}