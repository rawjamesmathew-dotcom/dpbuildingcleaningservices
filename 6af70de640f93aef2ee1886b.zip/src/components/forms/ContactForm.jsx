import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2 } from "lucide-react";
import { submitContactInquiry } from "@/lib/server-fns";
import { SITE } from "@/lib/siteContent";
import { Consent, Field, Honeypot, Input, SubmitButton, Textarea } from "@/components/forms/fields";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const EMPTY = { name: "", email: "", phone: "", company: "", message: "", consent: false, honeypot: "" };

export default function ContactForm() {
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle");
  const [message, setMessage] = useState("");
  const submit = useServerFn(submitContactInquiry);

  const update = (key) => (event) => {
    const value = event.target.type === "checkbox" ? event.target.checked : event.target.value;
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    if (status === "submitting") return;

    const next = {};
    if (values.name.trim().length < 2) next.name = "Please enter your name.";
    if (!EMAIL_RE.test(values.email.trim())) next.email = "Please enter a valid email address.";
    if (values.message.trim().length < 10) next.message = "Please write a little more detail.";
    if (!values.consent) next.consent = "Please confirm the privacy notice to continue.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setStatus("submitting");
    setMessage("");

    try {
      const result = await submit({ data: values });
      if (result?.ok) {
        setStatus("success");
      } else {
        setStatus("error");
        setMessage(result?.message || "We could not send your message. Please try again.");
      }
    } catch (error) {
      setStatus("error");
      setMessage("Something went wrong while sending your message. Please try again or email us.");
    }
  };

  if (status === "success") {
    return (
      <div className="rounded-[26px] border border-brand-line bg-white p-8">
        <span className="grid h-12 w-12 place-items-center rounded-full bg-brand-ice text-brand-blue">
          <CheckCircle2 className="h-6 w-6" aria-hidden="true" />
        </span>
        <h2 className="display-md mt-6 text-brand-navy">Message received.</h2>
        <p className="mt-3 text-[15px] leading-relaxed text-brand-slate">
          Thank you — your message has been logged and our team will reply using the details you
          provided.
        </p>
        <button
          type="button"
          onClick={() => {
            setValues(EMPTY);
            setStatus("idle");
          }}
          className="mt-6 rounded-full border border-brand-line px-5 py-3 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="rounded-[26px] border border-brand-line bg-white p-6 sm:p-8">
      <Honeypot value={values.honeypot} onChange={update("honeypot")} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" htmlFor="c-name" required error={errors.name}>
          <Input id="c-name" autoComplete="name" value={values.name} onChange={update("name")} placeholder="Your name" />
        </Field>
        <Field label="Email" htmlFor="c-email" required error={errors.email}>
          <Input id="c-email" type="email" autoComplete="email" value={values.email} onChange={update("email")} placeholder="you@company.com" />
        </Field>
        <Field label="Phone" htmlFor="c-phone">
          <Input id="c-phone" type="tel" autoComplete="tel" value={values.phone} onChange={update("phone")} placeholder="Include country code" />
        </Field>
        <Field label="Company" htmlFor="c-company">
          <Input id="c-company" autoComplete="organization" value={values.company} onChange={update("company")} placeholder="Optional" />
        </Field>
      </div>

      <div className="mt-5">
        <Field label="Message" htmlFor="c-message" required error={errors.message}>
          <Textarea
            id="c-message"
            value={values.message}
            onChange={update("message")}
            placeholder="How can we help? Include the property type and what you need if it is a service enquiry."
          />
        </Field>
      </div>

      <div className="mt-5">
        <Consent id="c-consent" checked={values.consent} onChange={update("consent")} error={errors.consent}>
          I agree that {SITE.name} may use the details I have provided to respond to this message, as
          described in the{" "}
          <a href="/privacy" className="font-semibold text-brand-blue underline">
            privacy policy
          </a>
          .
        </Consent>
      </div>

      {status === "error" && (
        <p role="alert" className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-[13.5px] text-red-700">
          {message} You can also email{" "}
          <a href={`mailto:${SITE.emails.primary}`} className="font-semibold underline">
            {SITE.emails.primary}
          </a>
          .
        </p>
      )}

      <div className="mt-7">
        <SubmitButton loading={status === "submitting"}>
          {status === "submitting" ? "Sending message" : "Send message"}
        </SubmitButton>
      </div>
    </form>
  );
}