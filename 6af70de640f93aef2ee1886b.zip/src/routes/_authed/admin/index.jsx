const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowUpRight, Briefcase, FolderOpen, Inbox, MessageSquareQuote } from "lucide-react";

export const Route = createFileRoute("/_authed/admin/")({ component: AdminOverview });

const CARDS = [
  {
    key: "inquiries",
    entity: "ContactInquiry",
    label: "Enquiries",
    to: "/admin/inquiries",
    icon: Inbox,
  },
  {
    key: "quotes",
    entity: "QuoteRequest",
    label: "Quote requests",
    to: "/admin/quotes",
    icon: MessageSquareQuote,
  },
  {
    key: "applications",
    entity: "JobApplication",
    label: "Applications",
    to: "/admin/applications",
    icon: Briefcase,
  },
  {
    key: "projects",
    entity: "Project",
    label: "Gallery images",
    to: "/admin/projects",
    icon: FolderOpen,
  },
];

function AdminOverview() {
  const [counts, setCounts] = useState({});
  const [newCounts, setNewCounts] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const run = async () => {
      try {
        const totals = await Promise.all(CARDS.map((card) => db.entities[card.entity].count({})));
        const fresh = await Promise.all([
          db.entities.ContactInquiry.count({ status: "new" }),
          db.entities.QuoteRequest.count({ status: "new" }),
          db.entities.JobApplication.count({ status: "new" }),
          db.entities.Service.count({}),
        ]);
        if (!active) return;
        setCounts({
          inquiries: totals[0],
          quotes: totals[1],
          applications: totals[2],
          projects: totals[3],
          services: fresh[3],
        });
        setNewCounts({
          inquiries: fresh[0],
          quotes: fresh[1],
          applications: fresh[2],
        });
      } finally {
        if (active) setLoading(false);
      }
    };
    run();
    return () => {
      active = false;
    };
  }, []);

  return (
    <div>
      <header className="mb-8">
        <h1 className="display-md text-brand-navy">Overview</h1>
        <p className="mt-2 max-w-2xl text-[14px] text-brand-slate">
          Submissions from the website, services and gallery content — all managed here.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {CARDS.map((card) => {
          const Icon = card.icon;
          return (
            <Link
              key={card.key}
              to={card.to}
              className="group rounded-2xl border border-brand-line bg-white p-5 transition-all hover:-translate-y-0.5 hover:shadow-[0_20px_50px_-34px_rgba(7,29,59,0.6)]"
            >
              <div className="flex items-start justify-between">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-ice text-brand-blue">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <ArrowUpRight className="h-4 w-4 text-brand-slate/40 transition-colors group-hover:text-brand-blue" aria-hidden="true" />
              </div>
              <p className="mt-5 font-display text-[28px] font-extrabold leading-none text-brand-navy">
                {loading ? "—" : counts[card.key] ?? 0}
              </p>
              <p className="mt-1.5 text-[13px] font-medium text-brand-slate">{card.label}</p>
              {newCounts[card.key] > 0 && (
                <p className="mt-2 inline-flex rounded-full bg-brand-blue/10 px-2.5 py-1 text-[11px] font-semibold text-brand-blue">
                  {newCounts[card.key]} new
                </p>
              )}
            </Link>
          );
        })}
      </div>

      <div className="mt-8 grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-brand-line bg-white p-6 lg:col-span-2">
          <h2 className="font-display text-[16px] font-bold text-brand-navy">What to do next</h2>
          <ul className="mt-4 space-y-3 text-[13.5px] leading-relaxed text-brand-slate">
            <li>
              1. Review new submissions and update their status so nothing sits unanswered.
            </li>
            <li>
              2. Keep the services list and gallery images accurate — they publish straight to the
              website.
            </li>
            <li>
              3. Add a verified phone number, WhatsApp number and working hours in Site settings once
              the company confirms them; those details stay hidden until you add them.
            </li>
          </ul>
        </div>
        <div className="rounded-2xl border border-brand-line bg-brand-navy p-6 text-white">
          <h2 className="font-display text-[16px] font-bold">Live content</h2>
          <p className="mt-2 text-[13px] leading-relaxed text-white/60">
            {loading ? "Checking…" : `${counts.services ?? 0} services published`}
          </p>
          <Link
            to="/admin/services"
            className="mt-4 inline-flex rounded-full bg-white px-4 py-2 text-[12.5px] font-semibold text-brand-navy"
          >
            Manage services
          </Link>
        </div>
      </div>
    </div>
  );
}