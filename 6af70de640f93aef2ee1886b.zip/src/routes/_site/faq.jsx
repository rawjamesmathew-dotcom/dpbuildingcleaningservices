import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import PageHeader from "@/components/site/PageHeader";
import FaqAccordion from "@/components/site/FaqAccordion";

export const Route = createFileRoute("/_site/faq")({
  component: FaqPage,
  head: () => ({
    meta: [
      { title: "Frequently Asked Questions | Deshani Prasang Building Services" },
      {
        name: "description",
        content:
          "How quotations work, what information helps us quote, which services are available and what happens after you submit a request.",
      },
      { property: "og:title", content: "Frequently Asked Questions" },
      { property: "og:description", content: "Answers about quotations, scheduling and services." },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
  }),
});

function FaqPage() {
  return (
    <>
      <PageHeader
        eyebrow="FAQ"
        title="Questions, answered without the sales language."
        intro="If something here does not cover your situation, send it to our team directly — we will answer it the same way."
      />

      <section className="bg-white py-16 sm:py-24">
        <div className="shell">
          <FaqAccordion />

          <div className="mt-16 flex flex-col items-start justify-between gap-5 rounded-[24px] border border-brand-line bg-brand-mist p-8 sm:flex-row sm:items-center">
            <div>
              <h2 className="display-md text-brand-navy">Still have a question?</h2>
              <p className="mt-2 max-w-xl text-[14.5px] text-brand-slate">
                Email the team or send a message through the contact form.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-brand-navy px-6 py-3.5 text-[14px] font-semibold text-white transition-colors hover:bg-brand-blue"
              >
                Contact us
              </Link>
              <Link
                to="/quote"
                className="group inline-flex items-center gap-2 rounded-full border border-brand-line bg-white px-6 py-3.5 text-[14px] font-semibold text-brand-navy transition-colors hover:border-brand-blue"
              >
                Get a quote
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}