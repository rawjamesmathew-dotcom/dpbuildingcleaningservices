import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import Hero from "@/components/site/Hero";
import Highlights from "@/components/site/Highlights";
import IntroSection from "@/components/site/IntroSection";
import ServicesGrid from "@/components/site/ServicesGrid";
import WhySection from "@/components/site/WhySection";
import ProcessSteps from "@/components/site/ProcessSteps";
import GalleryGrid from "@/components/site/GalleryGrid";
import StandardSection from "@/components/site/StandardSection";
import ReviewsSection from "@/components/site/ReviewsSection";
import FaqAccordion from "@/components/site/FaqAccordion";
import FinalCta from "@/components/site/FinalCta";
import SectionHeading from "@/components/site/SectionHeading";
import Reveal from "@/components/site/Reveal";
import { getPublicProjects, getPublicReviews, getPublicServices } from "@/lib/content-fns";

export const Route = createFileRoute("/_site/")({
  component: HomePage,
  loader: async () => ({
    services: await getPublicServices(),
    projects: await getPublicProjects(),
    reviews: await getPublicReviews(),
  }),
  head: () => ({
    meta: [
      { title: "Deshani Prasang Building Services | Professional Building Cleaning" },
      {
        name: "description",
        content:
          "Discover professional building cleaning services from Deshani Prasang Building Services. Contact our team to discuss your cleaning requirements and request a quotation.",
      },
      {
        property: "og:title",
        content: "Deshani Prasang Building Services | Professional Building Cleaning",
      },
      {
        property: "og:description",
        content:
          "Office, building, glass and facade cleaning, floor care and post-construction cleaning. Request a quotation for your property.",
      },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
});

function HomePage() {
  const { services, projects, reviews } = Route.useLoaderData();
  return (
    <>
      <Hero />
      <Highlights />
      <IntroSection />

      <section className="bg-brand-mist py-20 sm:py-28" aria-labelledby="services-heading">
        <div className="shell">
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
            <SectionHeading
              eyebrow="Services"
              title="Six disciplines. One standard."
              intro="Each service is scoped individually — you tell us the property, we confirm what the work includes before anything begins."
            />
            <Link
              to="/services"
              className="group inline-flex shrink-0 items-center gap-2 border-b border-brand-navy/20 pb-1.5 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue hover:text-brand-blue"
            >
              All services
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </div>
          <h2 id="services-heading" className="sr-only">
            Our cleaning services
          </h2>
          <div className="mt-12">
            <ServicesGrid services={services} />
          </div>
        </div>
      </section>

      <WhySection />
      <ProcessSteps />
      <ReviewsSection reviews={reviews} />

      <section className="bg-white py-20 sm:py-28" aria-labelledby="gallery-heading">
        <div className="shell">
          <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
            <SectionHeading
              eyebrow="Project gallery"
              title="The environments we look after."
              intro="These images are illustrative references of the spaces our services are designed for — not completed company projects. Approved project photography will replace them."
            />
            <Link
              to="/projects"
              className="group inline-flex shrink-0 items-center gap-2 border-b border-brand-navy/20 pb-1.5 text-[13.5px] font-semibold text-brand-navy transition-colors hover:border-brand-blue hover:text-brand-blue"
            >
              View gallery
              <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          </div>
          <h2 id="gallery-heading" className="sr-only">
            Project gallery
          </h2>
          <Reveal className="mt-12">
            <GalleryGrid items={projects.slice(0, 4)} />
          </Reveal>
        </div>
      </section>

      <StandardSection />

      <section className="bg-brand-mist py-20 sm:py-28" aria-labelledby="faq-heading">
        <div className="shell">
          <h2 id="faq-heading" className="sr-only">
            Frequently asked questions
          </h2>
          <FaqAccordion />
        </div>
      </section>

      <FinalCta />
    </>
  );
}