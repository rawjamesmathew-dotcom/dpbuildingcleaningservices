import { STANDARDS } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";
import SectionHeading from "@/components/site/SectionHeading";

// Replaces a testimonials block: no approved customer reviews have been
// supplied, so this section states the service standard instead of
// inventing quotes or ratings.
export default function StandardSection() {
  return (
    <section className="bg-white py-20 sm:py-28">
      <div className="shell">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
          <div>
            <SectionHeading
              eyebrow="Our service standard"
              title="What we hold ourselves to, every visit."
              intro="Customer reviews will appear here once real, approved feedback is available. Until then, this is the standard our work is measured against."
            />
            <div className="mt-8 rounded-2xl border border-dashed border-brand-line bg-brand-mist p-5">
              <p className="text-[13px] leading-relaxed text-brand-slate">
                <span className="font-semibold text-brand-navy">Note on reviews:</span> we do not
                display ratings or quotations that cannot be verified. Approved customer feedback
                will be published with permission.
              </p>
            </div>
          </div>

          <div className="grid gap-px overflow-hidden rounded-3xl border border-brand-line bg-brand-line sm:grid-cols-2">
            {STANDARDS.map((item, i) => (
              <Reveal key={item.label} delay={(i % 2) * 0.06} className="h-full">
                <div className="group h-full bg-white p-7 transition-colors duration-500 hover:bg-brand-ice/50">
                  <div className="flex items-baseline justify-between">
                    <span className="font-mono text-[11px] tracking-[0.14em] text-brand-blue">
                      {item.label}
                    </span>
                    <span className="h-px w-10 bg-brand-line transition-all duration-500 group-hover:w-16 group-hover:bg-brand-cyan" />
                  </div>
                  <h3 className="mt-5 font-display text-[17px] font-bold tracking-[-0.02em] text-brand-navy">
                    {item.title}
                  </h3>
                  <p className="mt-2.5 text-[14px] leading-relaxed text-brand-slate">{item.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}