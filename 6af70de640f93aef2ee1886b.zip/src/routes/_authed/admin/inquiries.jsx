import { createFileRoute } from "@tanstack/react-router";
import SubmissionList from "@/components/admin/SubmissionList";

export const Route = createFileRoute("/_authed/admin/inquiries")({ component: InquiriesPage });

function InquiriesPage() {
  return (
    <SubmissionList
      entity="ContactInquiry"
      title="Enquiries"
      description="Messages sent through the contact form. Update the status as you respond."
      statusOptions={["new", "in_progress", "closed"]}
      fields={[
        { key: "name", label: "Name" },
        { key: "email", label: "Email" },
        { key: "phone", label: "Phone" },
        { key: "company", label: "Company" },
        { key: "message", label: "Message", wide: true },
      ]}
    />
  );
}