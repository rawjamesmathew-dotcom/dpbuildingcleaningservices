import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { IMAGES, SITE } from "@/lib/siteContent";
import Reveal from "@/components/site/Reveal";
import SectionHeading from "@/components/site/SectionHeading";

export default function IntroSection() {
  return (
    <section className="relative overflow-hidden bg-white py-20 sm:py-28">
      <div className="shell grid items-center gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
        <Reveal className="relative">
          <div className="relative overflow-hidden rounded-[26px] border border-brand-line">
            <Image
              src={IMAGES.about}
              alt="Close-up of a gloved hand wiping a chrome handrail in a bright glass atrium"
              className="h-[340px] w-full object-cover sm:h-[440px]"
              fittingType="fill"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/35 via-transparent to-transparent" />
          </div>
          <div className="absolute -bottom-6 left-5 hidden rounded-2xl border border-brand-line bg-white/95 px-5 py-4 shadow-[0_24px_60px_-40px_rgba(7,29,59,0.8)] backdrop-blur sm:block">
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.22em] text-brand-slate">
              Registered as
            </p>
            <p className="mt-1.5 font-display text-[13.5px] font-bold leading-snug tracking-[-0.01em] text-brand-navy">
              {SITE.legalName}
            </p>
          </div>
        </Reveal>

        <div>
          <SectionHeading
            eyebrow="The company"
            title="A building is judged by how it feels to walk into."
          />
          <div className="mt-6 space-y-4 text-[16.5px] leading-[1.75] text-brand-slate">
            <p>
              {SITE.intro} Cleaning is the visible part of how a property is managed: the entrance
              glass, the lift lobby, the floor a visitor crosses before they meet you.
            </p>
            <p>
              We also take on home works and repair jobs, so one team can cover both the cleaning
              programme and the maintenance that a property needs.
            </p>
            <p>
              We work to a simple principle — agree the standard first, then protect it. Every
              request goes through the same steps: understand the property, define the scope, quote
              it honestly, and deliver what was agreed.
            </p>
          </div>

          <dl className="mt-9 grid gap-px overflow-hidden rounded-2xl border border-brand-line bg-brand-line sm:grid-cols-2">
            {[
              { term: "Approach", detail: "Scope-led, quotation-based service" },
              { term: "Coverage", detail: "Commercial and residential buildings" },
              { term: "Working style", detail: "Scheduled or one-off visits" },
              { term: "Contact", detail: "Direct email with our team" },
            ].map((row) => (
              <div key={row.term} className="bg-white px-5 py-4">
                <dt className="text-[10.5px] font-semibold uppercase tracking-[0.2em] text-brand-slate">
                  {row.term}
                </dt>
                <dd className="mt-1.5 text-[14.5px] font-medium text-brand-navy">{row.detail}</dd>
              </div>
            ))}
          </dl>

          <Link
            to="/about"
            className="group mt-9 inline-flex items-center gap-2 border-b border-brand-line pb-1.5 text-[14px] font-semibold text-brand-blue transition-colors hover:border-brand-blue"
          >
            More about our approach
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </section>
  );
}