const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_authed/admin/services")({ component: ServicesAdmin });

const EMPTY = {
  name: "",
  slug: "",
  summary: "",
  description: "",
  category: "Interior",
  image_url: "",
  suitable_for: "",
  includes: "",
  published: true,
  display_order: 0,
};

const inputClass =
  "w-full rounded-xl border border-brand-line bg-white px-3.5 py-2.5 text-[13.5px] text-brand-navy focus:border-brand-blue focus:outline-none";

function ServicesAdmin() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");

  const load = async () => {
    setLoading(true);
    const page = await db.entities.Service.list("-created_date", 100);
    const list = (Array.isArray(page) ? page : page?.items ?? []).sort(
      (a, b) => (a.display_order ?? 0) - (b.display_order ?? 0)
    );
    setItems(list);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const startEdit = (item) => {
    setEditingId(item.id);
    setForm({
      name: item.name ?? "",
      slug: item.slug ?? "",
      summary: item.summary ?? "",
      description: item.description ?? "",
      category: item.category ?? "",
      image_url: item.image_url ?? "",
      suitable_for: item.suitable_for ?? "",
      includes: Array.isArray(item.includes) ? item.includes.join(", ") : item.includes ?? "",
      published: item.published !== false,
      display_order: item.display_order ?? 0,
    });
    setNotice("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const reset = () => {
    setEditingId(null);
    setForm(EMPTY);
  };

  const save = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.name.trim() || !form.slug.trim()) {
      setNotice("Name and URL slug are required.");
      return;
    }
    setSaving(true);
    const payload = {
      ...form,
      includes: form.includes
        .split(",")
        .map((value) => value.trim())
        .filter(Boolean),
      display_order: Number(form.display_order) || 0,
    };
    try {
      if (editingId) {
        await db.entities.Service.update(editingId, payload);
        setNotice("Service updated — the website now shows these changes.");
      } else {
        await db.entities.Service.create(payload);
        setNotice("Service added — the website now shows it.");
      }
      reset();
      await load();
    } catch (error) {
      setNotice("Could not save. Check the details and try again.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this service? It will disappear from the website.")) return;
    await db.entities.Service.delete(id);
    if (editingId === id) reset();
    await load();
  };

  return (
    <div>
      <header className="mb-6">
        <h1 className="display-md text-brand-navy">Services</h1>
        <p className="mt-2 max-w-2xl text-[14px] text-brand-slate">
          Published services appear on the home page and services page. The website falls back to the
          built-in service list while this table is empty.
        </p>
      </header>

      <form onSubmit={save} className="rounded-2xl border border-brand-line bg-white p-5 sm:p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-[15px] font-bold text-brand-navy">
            {editingId ? "Edit service" : "Add a service"}
          </h2>
          {editingId && (
            <button type="button" onClick={reset} className="text-[12.5px] font-medium text-brand-slate hover:text-brand-navy">
              Cancel edit
            </button>
          )}
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Name
            <input
              className={`${inputClass} mt-1.5`}
              value={form.name}
              onChange={(event) => setForm({ ...form, name: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            URL slug
            <input
              className={`${inputClass} mt-1.5`}
              value={form.slug}
              onChange={(event) => setForm({ ...form, slug: event.target.value })}
              placeholder="office-cleaning"
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Category
            <input
              className={`${inputClass} mt-1.5`}
              value={form.category}
              onChange={(event) => setForm({ ...form, category: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Display order
            <input
              type="number"
              className={`${inputClass} mt-1.5`}
              value={form.display_order}
              onChange={(event) => setForm({ ...form, display_order: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Image URL
            <input
              className={`${inputClass} mt-1.5`}
              value={form.image_url}
              onChange={(event) => setForm({ ...form, image_url: event.target.value })}
              placeholder="https://…"
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Summary
            <input
              className={`${inputClass} mt-1.5`}
              value={form.summary}
              onChange={(event) => setForm({ ...form, summary: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Description
            <textarea
              className={`${inputClass} mt-1.5 min-h-[90px]`}
              value={form.description}
              onChange={(event) => setForm({ ...form, description: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            What is included (comma separated)
            <input
              className={`${inputClass} mt-1.5`}
              value={form.includes}
              onChange={(event) => setForm({ ...form, includes: event.target.value })}
            />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Suitable for
            <input
              className={`${inputClass} mt-1.5`}
              value={form.suitable_for}
              onChange={(event) => setForm({ ...form, suitable_for: event.target.value })}
            />
          </label>
          <label className="flex items-center gap-2 text-[13px] text-brand-navy sm:col-span-2">
            <input
              type="checkbox"
              checked={form.published}
              onChange={(event) => setForm({ ...form, published: event.target.checked })}
              className="h-4 w-4 rounded border-brand-line text-brand-blue"
            />
            Published on the website
          </label>
        </div>

        {notice && <p className="mt-4 rounded-xl bg-brand-ice p-3 text-[12.5px] text-brand-navy">{notice}</p>}

        <button
          type="submit"
          disabled={saving}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand-navy px-5 py-2.5 text-[13px] font-semibold text-white disabled:opacity-60"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          {saving ? "Saving" : editingId ? "Save changes" : "Add service"}
        </button>
      </form>

      <div className="mt-8 space-y-2">
        {loading ? (
          <p className="text-[13px] text-brand-slate">Loading services…</p>
        ) : items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-brand-line bg-white p-6 text-[13px] text-brand-slate">
            No services in the database yet — the website is showing the built-in list. Add one here
            to take control of the content.
          </p>
        ) : (
          items.map((item) => (
            <div
              key={item.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand-line bg-white px-4 py-3"
            >
              <div className="min-w-0">
                <p className="truncate text-[13.5px] font-semibold text-brand-navy">
                  {item.name}
                  {item.published === false && (
                    <span className="ml-2 rounded-full bg-brand-mist px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.1em] text-brand-slate">
                      hidden
                    </span>
                  )}
                </p>
                <p className="truncate text-[12px] text-brand-slate">/services/{item.slug}</p>
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => startEdit(item)}
                  className="rounded-lg border border-brand-line px-3 py-1.5 text-[12.5px] font-medium text-brand-navy hover:border-brand-blue"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => remove(item.id)}
                  aria-label={`Delete ${item.name}`}
                  className="rounded-lg border border-red-200 px-2.5 py-1.5 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}