const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { Plus, Trash2 } from "lucide-react";
import { Image } from "@/components/ui/image";

export const Route = createFileRoute("/_authed/admin/projects")({ component: ProjectsAdmin });

const EMPTY = { title: "", category: "", description: "", image_url: "", illustrative: true, published: true };

const inputClass =
  "w-full rounded-xl border border-brand-line bg-white px-3.5 py-2.5 text-[13.5px] text-brand-navy focus:border-brand-blue focus:outline-none";

function ProjectsAdmin() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");

  const load = async () => {
    setLoading(true);
    const page = await db.entities.Project.list("-created_date", 100);
    setItems(Array.isArray(page) ? page : page?.items ?? []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const startEdit = (item) => {
    setEditingId(item.id);
    setForm({
      title: item.title ?? "",
      category: item.category ?? "",
      description: item.description ?? "",
      image_url: item.image_url ?? "",
      illustrative: item.illustrative !== false,
      published: item.published !== false,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const reset = () => {
    setEditingId(null);
    setForm(EMPTY);
  };

  const save = async (event) => {
    event.preventDefault();
    if (!form.title.trim() || !form.image_url.trim()) {
      setNotice("A title and image URL are required.");
      return;
    }
    if (editingId) {
      await db.entities.Project.update(editingId, form);
      setNotice("Image updated.");
    } else {
      await db.entities.Project.create(form);
      setNotice("Image added to the gallery.");
    }
    reset();
    await load();
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this gallery image?")) return;
    await db.entities.Project.delete(id);
    if (editingId === id) reset();
    await load();
  };

  return (
    <div>
      <header className="mb-6">
        <h1 className="display-md text-brand-navy">Gallery</h1>
        <p className="mt-2 max-w-2xl text-[14px] text-brand-slate">
          Add real project photographs here and switch off the illustrative label once they are
          approved for publication. Upload your image first, then paste its public URL.
        </p>
      </header>

      <form onSubmit={save} className="rounded-2xl border border-brand-line bg-white p-5 sm:p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-[15px] font-bold text-brand-navy">
            {editingId ? "Edit image" : "Add an image"}
          </h2>
          {editingId && (
            <button type="button" onClick={reset} className="text-[12.5px] font-medium text-brand-slate hover:text-brand-navy">
              Cancel edit
            </button>
          )}
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Title
            <input className={`${inputClass} mt-1.5`} value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy">
            Category
            <input className={`${inputClass} mt-1.5`} value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })} placeholder="Lobbies, Facades, Interiors…" />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Image URL
            <input className={`${inputClass} mt-1.5`} value={form.image_url} onChange={(event) => setForm({ ...form, image_url: event.target.value })} placeholder="https://…" />
          </label>
          <label className="text-[12px] font-semibold uppercase tracking-[0.1em] text-brand-navy sm:col-span-2">
            Caption
            <input className={`${inputClass} mt-1.5`} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
          </label>
          <label className="flex items-center gap-2 text-[13px] text-brand-navy">
            <input type="checkbox" checked={form.illustrative} onChange={(event) => setForm({ ...form, illustrative: event.target.checked })} className="h-4 w-4 rounded border-brand-line text-brand-blue" />
            Illustrative image (not a company project)
          </label>
          <label className="flex items-center gap-2 text-[13px] text-brand-navy">
            <input type="checkbox" checked={form.published} onChange={(event) => setForm({ ...form, published: event.target.checked })} className="h-4 w-4 rounded border-brand-line text-brand-blue" />
            Show in gallery
          </label>
        </div>

        {notice && <p className="mt-4 rounded-xl bg-brand-ice p-3 text-[12.5px] text-brand-navy">{notice}</p>}

        <button type="submit" className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand-navy px-5 py-2.5 text-[13px] font-semibold text-white">
          <Plus className="h-4 w-4" aria-hidden="true" />
          {editingId ? "Save changes" : "Add image"}
        </button>
      </form>

      <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {loading ? (
          <p className="text-[13px] text-brand-slate">Loading gallery…</p>
        ) : items.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-brand-line bg-white p-6 text-[13px] text-brand-slate sm:col-span-2 xl:col-span-3">
            No gallery images in the database yet — the website is showing the built-in illustrative
            set.
          </p>
        ) : (
          items.map((item) => (
            <article key={item.id} className="overflow-hidden rounded-2xl border border-brand-line bg-white">
              <div className="aspect-[4/3] bg-brand-ice">
                <Image src={item.image_url} alt={item.title} className="h-full w-full object-cover" fittingType="fill" />
              </div>
              <div className="p-4">
                <p className="text-[13.5px] font-semibold text-brand-navy">{item.title}</p>
                <p className="mt-0.5 text-[12px] text-brand-slate">{item.category}</p>
                <div className="mt-3 flex gap-2">
                  <button type="button" onClick={() => startEdit(item)} className="rounded-lg border border-brand-line px-3 py-1.5 text-[12px] font-medium text-brand-navy">
                    Edit
                  </button>
                  <button type="button" onClick={() => remove(item.id)} aria-label={`Delete ${item.title}`} className="rounded-lg border border-red-200 px-2.5 py-1.5 text-red-600">
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>
            </article>
          ))
        )}
      </div>
    </div>
  );
}